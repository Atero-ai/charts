{{/*
Expand the name of the chart.
*/}}
{{- define "ateroModel.name" -}}
{{- coalesce .Values.nameOverride .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ateroModel.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "atero-kvcache-model.fullname" -}}
{{- printf "%s-%s" .Release.Name "model" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ateroModel.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ateroModel.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
helm.sh/chart: {{ include "ateroModel.chart" . }}
{{- end }}

{{- define "ateroModel.labels" -}}
{{ include "ateroModel.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- if .Values.common.labels }}
{{- range $key, $value := .Values.common.labels }}
{{ $key }}: {{ $value | quote }}
{{- end }}
{{- end }}
{{- if .Values.model.labels }}
{{- range $key, $value := .Values.model.labels }}
{{ $key }}: {{ $value | quote }}
{{- end }}
{{- end }}
{{- end }}

{{- define "atero-etcd.fullname" -}}
{{- if .Values.common.etcd.endpoint -}}
{{- .Values.common.etcd.endpoint }}
{{- else -}}
{{- printf "%s-%s" .Values.common.ateroDeploymentReleaseName "etcd" | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{- define "atero-kvcm.fullname" -}}
{{- if .Values.common.kvcm.endpoint -}}
{{- .Values.common.kvcm.endpoint }}
{{- else -}}
{{- printf "%s-%s" .Values.common.ateroDeploymentReleaseName "kvcm-server" | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Volumes for PD containers based on model artifact prefix
Context is .Values.modelArtifacts
*/}}
{{- define "ateroModel.mountModelVolumeVolumes" -}}
{{- $parsedArtifacts := regexSplit "://" .uri -1 -}}
{{- $protocol := first $parsedArtifacts -}}
{{- $path := last $parsedArtifacts -}}
{{- if eq $protocol "hf" -}}
- name: model-storage
  emptyDir: 
    sizeLimit: {{ default "0" .size }}
{{- else if eq $protocol "pvc" }}
{{- $parsedArtifacts := regexSplit "/" $path -1 -}}
{{- $claim := first $parsedArtifacts -}}
- name: model-storage
  persistentVolumeClaim:
    claimName: {{ $claim }}
{{- else if eq $protocol "fs" }}
- name: model-storage
  hostPath:
    path: "/{{ $path }}"
    type: Directory  # Use Directory without create since this usually use a mounted path
{{- end }}
{{- end }}

{{- define "atero.imagePullSecretValue" -}}
{{- printf "{\"auths\": {\"%s\": {\"auth\": \"%s\"}}}" (.Values.image.registry) (printf "%s:%s" (required "A valid username for image pull secret required" .Values.imagePullSecret.username) .Values.imagePullSecret.password | b64enc) | b64enc }}
{{- end }}
