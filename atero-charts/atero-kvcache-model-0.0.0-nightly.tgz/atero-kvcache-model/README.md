# Kube Atero Models

In order to deploy models, you need to helm install the `atero-kvcache-model` chart.

```bash
helm install atero-llama8b deployment/atero-kvcache-model deployment/llama-8b.yaml -n pytest
```
