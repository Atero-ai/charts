{{- define "atero-etcd.fullname" -}}
{{- if .Values.common.ateroDeployment.etcd.endpoint -}}
{{- .Values.common.ateroDeployment.etcd.endpoint }}
{{- else -}}
{{- printf "%s-%s" .Values.common.ateroDeployment.ateroDeploymentReleaseName "etcd" | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Volumes for PD containers based on model artifact prefix
Context is .Values.model.artifacts
*/}}
{{- define "ateroModel.mountModelVolumeVolumes" -}}
{{- $parsedArtifacts := regexSplit "://" .uri -1 -}}
{{- $protocol := first $parsedArtifacts -}}
{{- $path := last $parsedArtifacts -}}
{{- if eq $protocol "hf" -}}
- name: model-storage
  emptyDir:
    sizeLimit: {{ default "0" .size }}
{{- else if eq $protocol "pvc" }}
{{- $parsedArtifacts := regexSplit "/" $path -1 -}}
{{- $claim := first $parsedArtifacts -}}
- name: model-storage
  persistentVolumeClaim:
    claimName: {{ $claim }}
{{- else if eq $protocol "fs" }}
- name: model-storage
  hostPath:
    path: {{ printf "/%s" $path | quote }}
    type: Directory  # Use Directory without create since this usually uses a mounted path
{{- end }}
{{- end }}

