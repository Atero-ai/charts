# Vanilla Inference Deployment

Unified Helm chart for deploying vLLM or SGLang inference servers with optional Atero integration.

## Overview

Unified deployment for vllm and sglang selected via the `model.llmBackend` value.

## Quick Start

### Deploy model

```bash
helm install my-vllm-deployment deployment/vanilla-inference \
  -f deployment/vanilla-inference/examples/nvidia/h100_llama8b_values.yaml
```

## Configuration

### Required Values

- `model.llmBackend`: Must be either `"vllm"` or `"sglang"`
- `model.name`: The model name/path
- `model.image.repository`: Docker image repository
- `model.image.tag`: Docker image tag

### Common Configuration

Values that apply to both vLLM and SGLang:

- `common.architecture`: `"nvidia"` or `"amd"`

- `model.replicas`: Number of replicas (default: 1)
- `model.port`: Service port (default: 8000)
- `model.tensorParallelism`: Tensor parallel size (default: 1)
- `model.dataParallelism`: Data parallel size (default: 1)
- `model.gpuMemoryUtilization`: GPU memory utilization, 0-1 (default: 0.9)
- `model.maxModelLen`: Maximum context length (optional)
- `model.maxLogLen`: Maximum log length (default: 300, vLLM only)
- `model.artifacts.uri`: Model storage location (hf://, pvc://, or fs://)
- `model.resources`: Kubernetes resource requests/limits
- `model.logLevel`: Log level (default: "INFO")
- `model.extraArgs`: List of additional CLI arguments
- `model.chatTemplates.enabled`: Enable custom chat templates (default: false)
- `model.chatTemplates.templateFile`: Chat template filename

### vLLM-Specific Configuration

Values only used when `model.llmBackend: "vllm"`:

- `model.vllmApiKey.enabled`: Enable API key authentication
- `model.vllmApiKey.secretName`: Secret name containing the API key

### Chat Templates

Both vLLM and SGLang support custom chat templates. To use a custom template:

1. Create a ConfigMap with your template file:

```bash
kubectl create configmap my-release-chat-template \
  --from-file=template_chatml.jinja=path/to/your/template.jinja
```

1. Enable chat templates in your values:

```yaml
model:
  chatTemplates:
    enabled: true
    templateFile: "template_chatml.jinja"
```

The template will be mounted at `/templates/` in the container.

### Atero Integration

To enable Atero deployment features (etcd registration, lifecycle management):

```yaml
common:
  ateroDeployment:
    enabled: true
    ateroDeploymentReleaseName: "atero"
    etcd:
      endpoint: ""  # Optional: custom etcd endpoint
      port: 2379
      leaseTTL: 60

ateroImage:
  repository: registry.gitlab.com/crusoeenergy/atero/atero-um/atero-kube
  tag: "latest"

model:
  catalogParams:
    gpuBlocks: 0
    throttling:
      enabled: true
      throttleFactor: 1.0
      ttftCoefficients: []
    maxRequestsPerInstance:
      enabled: true
      defaultTier: 100
      serviceTier: 200
```

## Examples

See the `examples/` directory for specific deployment configurations

## Architecture

The deployment creates:

1. **Main Container**: Runs either vLLM or SGLang based on `model.llmBackend`
2. **Lifecycle Manager/Registrar** (optional): Atero integration sidecar for etcd registration
3. **Service**: ClusterIP service exposing the inference endpoint
4. **Volumes**: Shared memory, model storage (PVC/hostPath/emptyDir)

## Troubleshooting

### Check Backend Selection

```bash
kubectl get deployment <release-name>-inference -o jsonpath='{.spec.template.spec.containers[0].name}'
```

Should return either `vllm` or `sglang`.

### Validate Configuration

```bash
helm template my-release ./deployment/vanilla-inference -f my-values.yaml
```

Review the generated manifests to ensure correct backend configuration.
