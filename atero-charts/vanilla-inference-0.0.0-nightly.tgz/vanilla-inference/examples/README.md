# Vanilla Inference Examples

This directory contains example configurations for deploying
vLLM and SGLang with the unified vanilla-inference Helm chart.

## Prerequisites

```bash
# 1. Install minimal Atero
helm install atero deployment/atero -f amd_values.yaml

# 2. Create HuggingFace token secret
kubectl create secret generic hf-token --from-literal=HF_TOKEN=your_token_here
```

## NVIDIA Example

### SGLang with Llama-3.1-8B

**Configuration**: [nvidia/sglang_llama8b_values.yaml](nvidia/sglang_llama8b_values.yaml)

```bash
helm install llama8b-sglang deployment/vanilla-inference \
  -f deployment/vanilla-inference/examples/nvidia/sglang_llama8b_values.yaml
```

**Key settings**:

- Backend: `llmBackend: "sglang"`
- Single NVIDIA GPU with tensor parallelism = 1
- FP8 KV cache: `--kv-cache-dtype=fp8_e4m3`
- FlashInfer attention: `--attention-backend=flashinfer`
- GPU memory utilization: 80%

## AMD Example

### vLLM with Llama-3.1-8B

**Configuration**: [amd/vllm/llama8b_values.yaml](amd/vllm/llama8b_values.yaml)

```bash
helm install llama8b-vllm deployment/vanilla-inference \
  -f deployment/vanilla-inference/examples/amd/vllm/llama8b_values.yaml
```

**Key difference from NVIDIA**: Change `llmBackend: "vllm"` and `architecture: "amd"`.
All other settings (model URI, memory, parallelism) remain identical.
