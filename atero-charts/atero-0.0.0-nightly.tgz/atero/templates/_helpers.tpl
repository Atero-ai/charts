{{- define "atero-inference.fullname" -}}
{{- printf "%s-%s" .Release.Name "inference" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "atero-nexus.fullname" -}}
{{- printf "%s-%s" .Release.Name "nexus-server" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "atero-kvcm.fullname" -}}
{{- printf "%s-%s" .Release.Name "kvcm-server" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "atero-um.fullname" -}}
{{- printf "%s-%s" .Release.Name "um-service" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "atero-gateway.fullname" -}}
{{- printf "%s-%s" .Release.Name "gateway" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "atero-node-metrics.fullname" -}}
{{- printf "%s-%s" .Release.Name "node-metrics" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "atero-gateway-config.fullname" -}}
{{- printf "%s-config" (include "atero-gateway.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "atero-um-config.fullname" -}}
{{- printf "%s-config" (include "atero-um.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "atero-model-manager.fullname" -}}
{{- printf "%s-%s" .Release.Name "model-manager" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "atero-etcd.fullname" -}}
{{- if .Values.common.etcd.endpoint -}}
{{- .Values.common.etcd.endpoint }}
{{- else -}}
{{- printf "%s-%s" .Release.Name "etcd" | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Expand the name of the chart.
*/}}
{{- define "atero.name" -}}
{{- coalesce .Values.nameOverride .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "atero.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "atero.selectorLabels" -}}
app.kubernetes.io/name: {{ include "atero.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
helm.sh/chart: {{ include "atero.chart" . }}
{{- end }}

{{- define "atero.labels" -}}
{{ include "atero.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- if .Values.common.labels }}
{{- range $key, $value := .Values.common.labels }}
{{ $key }}: {{ $value | quote }}
{{- end }}
{{- end }}
{{- end }}

{{- /*
Helper to generate container names with an index, e.g. "inference-0", "inference-1", ...
*/ -}}
{{- define "atero-inference.containerName" -}}
atero-inference-{{ . }}
{{- end -}}

{{- define "atero.imagePullSecretValue" -}}
{{- printf "{\"auths\": {\"%s\": {\"auth\": \"%s\"}}}" (.Values.image.registry) (printf "%s:%s" (required "A valid username for image pull secret required" .Values.imagePullSecret.username) .Values.imagePullSecret.password | b64enc) | b64enc }}
{{- end }}

{{- define "atero.um.socket.host_mount_path" -}}
/dev/shm/{{ .Release.Name }}
{{- end -}}
