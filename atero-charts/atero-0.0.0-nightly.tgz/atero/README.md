# Kube Atero

In order to install atero we need to update files in `charts`, so run

```bash
$ helm dependency update deployment/atero
$ helm install atero deployment/atero deployment/nightly-cw.yaml -n pytest --set common.tag=v0.14.1
```
