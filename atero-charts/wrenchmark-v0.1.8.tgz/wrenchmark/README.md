# Wrenchmark Helm Chart

Helm chart for deploying the Wrenchmark application with unified image architecture.

## Architecture

Wrenchmark uses a single Docker image containing three services running under supervisord:

- **Frontend** (nginx on port 80) - React web UI
- **Backend** (FastAPI on port 8000, proxied by nginx at `/api`) - API server
- **Agent** (Streamlit on port 8501) - AI agent UI

All services run in a single container with shared environment and configuration.

## Installation

### Prerequisites

- Kubernetes cluster
- Helm 3.x
- Database secret (PostgreSQL connection string)
- Gemini credentials (for AI agent)
- GitLab registry access (imagePullSecrets)

### Quick Start

```bash
# Create secrets
kubectl create secret generic wrenchmark-db \
  --from-literal=connection-string="postgresql://user:pass@host:5432/dbname"

kubectl create secret generic wrenchmark-gemini \
  --from-file=credentials.json=/path/to/service-account.json

# Install chart
helm install wrenchmark ./charts/wrenchmark \
  --set database.existingSecret=wrenchmark-db \
  --set gemini.existingSecret=wrenchmark-gemini \
  --set gemini.projectId="your-gcp-project-id" \
  --set ingress.hosts[0].host="benchmark.yourdomain.com"
```

### Using Inline Values (Development Only)

```bash
helm install wrenchmark ./charts/wrenchmark \
  --set database.connectionString="postgresql://user:pass@host:5432/dbname" \
  --set gemini.projectId="your-gcp-project-id" \
  --set gemini.credentials="$(cat /path/to/credentials.json | base64)" \
  --set ingress.hosts[0].host="benchmark.yourdomain.com"
```

## Configuration

### Key Values

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.repository` | Docker image repository | `registry.gitlab.com/crusoeenergy/atero/wrenchmark/web` |
| `image.tag` | Image tag | `latest` |
| `replicaCount` | Number of replicas | `1` |
| `database.existingSecret` | Name of existing secret with DB connection string | `""` |
| `database.connectionString` | Inline DB connection string (dev only) | `""` |
| `gemini.projectId` | GCP project ID for Gemini API | `""` |
| `gemini.location` | GCP region for Gemini API | `us-central1` |
| `gemini.existingSecret` | Name of existing secret with credentials.json | `""` |
| `ingress.enabled` | Enable ingress | `true` |
| `ingress.hosts` | Ingress host configuration | See values.yaml |

### Complete Values

See [values.yaml](values.yaml) for all available configuration options.

### Custom Values File

Create a `values-custom.yaml`:

```yaml
image:
  tag: "v1.0.0"

database:
  existingSecret: "wrenchmark-db-prod"

gemini:
  projectId: "my-gcp-project"
  existingSecret: "wrenchmark-gemini-prod"

ingress:
  enabled: true
  className: "nginx"
  annotations:
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
  hosts:
    - host: benchmark.example.com
      paths:
        - path: /
          pathType: Prefix
          service: frontend
        - path: /agent
          pathType: Prefix
          service: agent
  tls:
    - secretName: benchmark-tls
      hosts:
        - benchmark.example.com

resources:
  requests:
    cpu: "2"
    memory: "4Gi"
  limits:
    cpu: "4"
    memory: "8Gi"
```

Install with:

```bash
helm install wrenchmark ./charts/wrenchmark -f values-custom.yaml
```

## Services

The chart creates two services:

1. **Frontend Service** (`<release>-wrenchmark-frontend`)
   - Port 80 (HTTP)
   - Serves frontend UI and proxies `/api` to backend

2. **Agent Service** (`<release>-wrenchmark-agent`)
   - Port 8501
   - Serves Streamlit agent UI

## Ingress

By default, the ingress routes:
- `/` → Frontend service (port 80)
- `/agent` → Agent service (port 8501)

The agent path may need adjustment depending on Streamlit's base URL handling.

## Health Checks

The deployment includes:
- **Liveness probe**: HTTP GET `/health` on port 80
- **Readiness probe**: HTTP GET `/health` on port 80

Configure probe timing in `values.yaml`:

```yaml
probes:
  liveness:
    enabled: true
    initialDelaySeconds: 30
    periodSeconds: 10
  readiness:
    enabled: true
    initialDelaySeconds: 15
    periodSeconds: 5
```

## Secrets

### Database Secret

Must contain a `connection-string` key:

```bash
kubectl create secret generic wrenchmark-db \
  --from-literal=connection-string="postgresql://user:pass@host:5432/dbname"
```

### Gemini Credentials Secret

Must contain a `credentials.json` key with GCP service account:

```bash
kubectl create secret generic wrenchmark-gemini \
  --from-file=credentials.json=/path/to/service-account.json
```

## Upgrading

```bash
# Upgrade with new image tag
helm upgrade wrenchmark ./charts/wrenchmark \
  --reuse-values \
  --set image.tag="v1.1.0"

# Upgrade with new values file
helm upgrade wrenchmark ./charts/wrenchmark -f values-custom.yaml
```

## Uninstalling

```bash
helm uninstall wrenchmark
```

## Troubleshooting

### Pod not starting

Check logs:
```bash
kubectl logs -f <pod-name>
```

Check events:
```bash
kubectl describe pod <pod-name>
```

### Database connection issues

Verify secret:
```bash
kubectl get secret wrenchmark-db -o jsonpath='{.data.connection-string}' | base64 -d
```

Test from pod:
```bash
kubectl exec -it <pod-name> -- env | grep DB_CONNECTION_STRING
```

### Gemini/AI agent not working

Verify credentials:
```bash
kubectl get secret wrenchmark-gemini -o jsonpath='{.data.credentials\.json}' | base64 -d | jq .
```

Check mounted credentials in pod:
```bash
kubectl exec -it <pod-name> -- cat /var/secrets/google/credentials.json | jq .
```

### Ingress not routing correctly

Check ingress:
```bash
kubectl get ingress
kubectl describe ingress <ingress-name>
```

Test services directly:
```bash
# Frontend
kubectl port-forward svc/<release>-wrenchmark-frontend 8080:80
curl http://localhost:8080/health

# Agent
kubectl port-forward svc/<release>-wrenchmark-agent 8501:8501
curl http://localhost:8501
```

## Development

### Testing Chart Locally

```bash
# Lint chart
helm lint charts/wrenchmark

# Dry-run render templates
helm template test charts/wrenchmark \
  --set database.connectionString="postgresql://..." \
  --set gemini.projectId="test-project"

# Install with debug
helm install --debug --dry-run test charts/wrenchmark -f values-dev.yaml
```

### Chart Structure

```
charts/wrenchmark/
├── Chart.yaml                      # Chart metadata
├── values.yaml                     # Default configuration
├── .helmignore                     # Files to ignore
├── README.md                       # This file
└── templates/
    ├── _helpers.tpl                # Template helpers
    ├── deployment.yaml             # Main deployment
    ├── frontend-service.yaml       # Frontend service (port 80)
    ├── agent-service.yaml          # Agent service (port 8501)
    ├── ingress.yaml                # Ingress routing
    └── secret.yaml                 # Optional inline secrets
```

## Production Considerations

1. **Use external secrets**: Don't use inline `connectionString` or `credentials` in production
2. **Enable TLS**: Configure ingress TLS with cert-manager
3. **Resource limits**: Adjust CPU/memory based on load
4. **Replicas**: Increase `replicaCount` for high availability
5. **Image tags**: Use specific version tags, not `latest`
6. **Monitoring**: Add Prometheus annotations for scraping
7. **Backup**: Ensure database has backup strategy

## License

See main project LICENSE file.
