# Wrenchmark Helm Chart - Implementation Summary

## What Was Created

ArgoCD-ready Helm charts for deploying the Wrenchmark unified image with frontend, backend, and agent services.

## Files Created

```
charts/wrenchmark/
├── Chart.yaml                      # Chart metadata (v0.1.0)
├── values.yaml                     # Default production values
├── values-development.yaml         # Development environment values
├── .helmignore                     # Packaging ignore patterns
├── README.md                       # Complete documentation
├── QUICKSTART.md                   # Quick start guide
├── IMPLEMENTATION_SUMMARY.md       # This file
└── templates/
    ├── _helpers.tpl                # Template helpers (labels, selectors, image)
    ├── deployment.yaml             # Main deployment (unified image)
    ├── frontend-service.yaml       # Service for port 80 (frontend + API)
    ├── agent-service.yaml          # Service for port 8501 (agent)
    ├── ingress.yaml                # Ingress with routing to both services
    └── secret.yaml                 # Optional inline secrets (dev only)
```

## Architecture Implementation

### Unified Image Approach

**Key Decision**: Single container with supervisord managing three processes
- ✅ Simpler deployment (1 container vs 3)
- ✅ Shared environment and configuration
- ✅ Single image to build and version
- ✅ Consistent resource limits

### Services

**Two ClusterIP Services** (not one):
1. `<release>-wrenchmark-frontend` (port 80)
   - Serves frontend UI
   - Proxies `/api` to backend

2. `<release>-wrenchmark-agent` (port 8501)
   - Serves Streamlit agent UI

**Rationale**: Separate services allow:
- Independent ingress routing
- Different service types if needed (e.g., LoadBalancer for agent)
- Better traffic management and monitoring

### Ingress Routing

```yaml
paths:
  - path: /              # Routes to frontend service
    service: frontend
  - path: /agent         # Routes to agent service
    service: agent
```

**Note**: Agent path may need adjustment based on Streamlit base URL handling.

## Configuration Strategy

### Secrets Management

**Two approaches supported**:

1. **External secrets** (production, recommended):
   ```yaml
   database:
     existingSecret: "wrenchmark-db"
   gemini:
     existingSecret: "wrenchmark-gemini"
   ```

2. **Inline values** (development only):
   ```yaml
   database:
     connectionString: "postgresql://..."
   gemini:
     credentials: "base64-encoded-json"
   ```

### Environment Variables

All services receive:
- `DB_CONNECTION_STRING` - From secret
- `GEMINI_PROJECT_ID` - From values
- `GEMINI_LOCATION` - From values (default: us-central1)
- `GOOGLE_APPLICATION_CREDENTIALS` - Mounted volume path (if using service account)

### Volume Mounts

**Conditional mounting**:
- Only mount Google credentials if `gemini.existingSecret` or `gemini.credentials` is set
- Mount path: `/var/secrets/google/credentials.json`
- Read-only mount for security

## Validation

### Linting

```bash
$ helm lint charts/wrenchmark
==> Linting charts/wrenchmark
[INFO] Chart.yaml: icon is recommended
1 chart(s) linted, 0 chart(s) failed
```

### Template Rendering

Tested scenarios:
- ✅ Inline secrets (dev mode)
- ✅ External secrets (prod mode)
- ✅ Development values file
- ✅ Ingress enabled/disabled
- ✅ Credentials present/absent

### Key Validations

1. **No secrets created when using `existingSecret`**:
   ```bash
   helm template test charts/wrenchmark \
     --set database.existingSecret="my-db" \
     --set gemini.existingSecret="my-gemini"
   # Result: No Secret resources in output ✓
   ```

2. **Correct secret references in deployment**:
   ```yaml
   env:
     - name: DB_CONNECTION_STRING
       valueFrom:
         secretKeyRef:
           name: my-db  # Correctly uses existingSecret ✓
   ```

3. **Proper service routing in ingress**:
   ```yaml
   - path: /
     backend:
       service:
         name: test-wrenchmark-frontend  # ✓
   - path: /agent
     backend:
       service:
         name: test-wrenchmark-agent  # ✓
   ```

## Differences from Plumber Chart

| Aspect | Plumber (Reference) | Wrenchmark (Implemented) |
|--------|---------------------|--------------------------|
| **Deployments** | Separate frontend/backend | Single unified deployment |
| **Containers** | 2+ separate containers | 1 container with supervisord |
| **Services** | Multiple services | 2 services (frontend + agent) |
| **Ports** | One per container | Two ports (80, 8501) |
| **ConfigMaps** | nginx config via ConfigMap | Config baked into image |
| **Workers** | Separate worker deployments | N/A (no workers) |
| **Complexity** | Higher (multiple components) | Lower (single component) |

## Health Checks

**Implemented probes**:
- Liveness: HTTP GET `/health` on port 80
- Readiness: HTTP GET `/health` on port 80

**Configurable timing**:
```yaml
probes:
  liveness:
    initialDelaySeconds: 30  # Production
    # or 10 for development
  readiness:
    initialDelaySeconds: 15  # Production
    # or 5 for development
```

## Resource Configuration

**Default limits** (production):
```yaml
resources:
  requests:
    cpu: "1"
    memory: "2Gi"
  limits:
    cpu: "2"
    memory: "4Gi"
```

**Development values**:
```yaml
resources:
  requests:
    cpu: "500m"
    memory: "1Gi"
  limits:
    cpu: "1"
    memory: "2Gi"
```

## Usage Examples

### Development Deployment

```bash
# 1. Create secrets
kubectl create secret generic benchmark-db-connection-dev \
  --from-literal=connection-string="postgresql://..."

kubectl create secret generic wrenchmark-gemini-dev \
  --from-file=credentials.json=creds.json

# 2. Install
helm install wrenchmark-dev charts/wrenchmark \
  -f charts/wrenchmark/values-development.yaml \
  -n atero

# 3. Access via port-forward
kubectl port-forward -n atero svc/wrenchmark-dev-wrenchmark-frontend 8080:80
kubectl port-forward -n atero svc/wrenchmark-dev-wrenchmark-agent 8501:8501
```

### Production Deployment

```bash
# 1. Create secrets (via 1Password or manually)
# ... (see QUICKSTART.md)

# 2. Create custom values file
cat > values-prod.yaml <<EOF
image:
  tag: "v1.0.0"
database:
  existingSecret: "wrenchmark-db"
gemini:
  projectId: "my-gcp-project"
  existingSecret: "wrenchmark-gemini"
ingress:
  enabled: true
  hosts:
    - host: benchmark.example.com
      paths:
        - path: /
          pathType: Prefix
          service: frontend
        - path: /agent
          pathType: Prefix
          service: agent
EOF

# 3. Install
helm install wrenchmark charts/wrenchmark \
  -f values-prod.yaml \
  -n atero
```

## Testing Checklist

- [x] Chart lints successfully
- [x] Templates render with default values
- [x] Templates render with development values
- [x] Templates render with external secrets
- [x] Templates render with inline secrets (dev)
- [x] Ingress routes to correct services
- [x] Environment variables reference correct secrets
- [x] Volumes mount correctly when credentials provided
- [x] No secrets created when using existingSecret
- [x] Labels and selectors match correctly
- [x] Health probes configured properly

## Next Steps

### Recommended Enhancements

1. **Add icon to Chart.yaml** (currently just a warning)
2. **Test actual deployment** in Kubernetes cluster
3. **Verify Streamlit base URL handling** for `/agent` path
4. **Add ServiceMonitor** for Prometheus scraping
5. **Add HPA** (HorizontalPodAutoscaler) for autoscaling
6. **Add PodDisruptionBudget** for high availability
7. **Configure cert-manager** for TLS certificates
8. **Add network policies** for security
9. **Document disaster recovery** procedures
10. **Create CI/CD pipeline** for chart publishing

### Integration with ArgoCD

To deploy via ArgoCD:

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: wrenchmark
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://gitlab.com/crusoeenergy/atero/wrenchmark.git
    targetRevision: main
    path: charts/wrenchmark
    helm:
      valueFiles:
        - values-production.yaml
  destination:
    server: https://kubernetes.default.svc
    namespace: atero
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
```

## Known Limitations

1. **Single replica only** - Current setup doesn't handle multi-replica concerns:
   - No shared session storage
   - No sticky sessions configured
   - Agent state may not persist across restarts

2. **Streamlit base URL** - May need configuration for sub-path routing

3. **No persistent storage** - Stateless deployment, any local state is lost on restart

4. **No backup/restore** - Database backup must be handled externally

## Documentation

- **README.md**: Complete chart documentation with all configuration options
- **QUICKSTART.md**: Step-by-step guide for quick deployment
- **IMPLEMENTATION_SUMMARY.md**: This file - architecture and decisions
- **values.yaml**: Inline comments explaining each option
- **values-development.yaml**: Development-specific configuration

## Verification Commands

```bash
# Lint
helm lint charts/wrenchmark

# Render with dry-run
helm install --dry-run --debug test charts/wrenchmark \
  -f charts/wrenchmark/values-development.yaml

# Template rendering
helm template test charts/wrenchmark > /tmp/rendered.yaml

# Check specific resources
helm template test charts/wrenchmark | grep -A 20 "kind: Deployment"
helm template test charts/wrenchmark | grep -A 10 "kind: Service"
helm template test charts/wrenchmark | grep -A 15 "kind: Ingress"
```

## Conclusion

The Wrenchmark Helm chart is complete and ready for deployment. It follows Helm best practices, is well-documented, and supports both development and production scenarios. The unified image architecture simplifies deployment while maintaining flexibility through comprehensive configuration options.

**Status**: ✅ Ready for testing and deployment
