# Wrenchmark Helm Chart - Quick Start

## 1. Prepare Secrets

### Option A: Using Existing Kubernetes Secrets (Recommended)

```bash
# Create database secret
kubectl create secret generic wrenchmark-db \
  --from-literal=connection-string="postgresql://user:pass@host:5432/benchmark" \
  -n atero

# Create Gemini credentials secret
kubectl create secret generic wrenchmark-gemini \
  --from-file=credentials.json=/path/to/service-account.json \
  -n atero
```

### Option B: Using 1Password (If Available)

```bash
# Sync from 1Password to K8s
op read "op://Engineering/benchmark-db-dev/connection-string" | \
  kubectl create secret generic wrenchmark-db \
    --from-file=connection-string=/dev/stdin \
    -n atero

# For Gemini credentials
op document get "wrenchmark-gemini-credentials.json" | \
  kubectl create secret generic wrenchmark-gemini \
    --from-file=credentials.json=/dev/stdin \
    -n atero
```

## 2. Install Chart

### Development Installation

```bash
helm install wrenchmark-dev charts/wrenchmark \
  -f charts/wrenchmark/values-development.yaml \
  -n atero
```

### Production Installation

```bash
helm install wrenchmark charts/wrenchmark \
  --set database.existingSecret="wrenchmark-db" \
  --set gemini.existingSecret="wrenchmark-gemini" \
  --set gemini.projectId="your-gcp-project-id" \
  --set image.tag="v1.0.0" \
  --set ingress.hosts[0].host="benchmark.yourdomain.com" \
  -n atero
```

### Custom Values File

Create `values-prod.yaml`:

```yaml
image:
  tag: "v1.0.0"

database:
  existingSecret: "wrenchmark-db"

gemini:
  projectId: "my-gcp-project"
  existingSecret: "wrenchmark-gemini"

ingress:
  enabled: true
  className: "nginx"
  hosts:
    - host: benchmark.example.com
      paths:
        - path: /
          pathType: Prefix
          service: frontend
        - path: /agent
          pathType: Prefix
          service: agent

resources:
  requests:
    cpu: "2"
    memory: "4Gi"
```

Then install:

```bash
helm install wrenchmark charts/wrenchmark -f values-prod.yaml -n atero
```

## 3. Verify Installation

```bash
# Check deployment status
kubectl get pods -n atero -l app.kubernetes.io/name=wrenchmark

# Check services
kubectl get svc -n atero -l app.kubernetes.io/name=wrenchmark

# Check ingress
kubectl get ingress -n atero
```

## 4. Access the Application

### Via Port-Forward (Development)

```bash
# Frontend + API
kubectl port-forward -n atero svc/wrenchmark-dev-wrenchmark-frontend 8080:80
# Visit: http://localhost:8080

# Agent
kubectl port-forward -n atero svc/wrenchmark-dev-wrenchmark-agent 8501:8501
# Visit: http://localhost:8501
```

### Via Ingress (Production)

Access via configured hostname:
- Frontend: `http://benchmark.example.com/`
- Agent: `http://benchmark.example.com/agent`

## 5. Check Logs

```bash
# Get pod name
POD=$(kubectl get pods -n atero -l app.kubernetes.io/name=wrenchmark -o jsonpath='{.items[0].metadata.name}')

# View logs
kubectl logs -f -n atero $POD

# View supervisord status
kubectl exec -it -n atero $POD -- supervisorctl status
```

## 6. Test Health Endpoints

```bash
# Port-forward first
kubectl port-forward -n atero svc/wrenchmark-dev-wrenchmark-frontend 8080:80

# Test health
curl http://localhost:8080/health

# Test backend API
curl http://localhost:8080/api/health
```

## 7. Upgrade

```bash
# Upgrade with new image
helm upgrade wrenchmark charts/wrenchmark \
  --reuse-values \
  --set image.tag="v1.1.0" \
  -n atero

# Upgrade with new values file
helm upgrade wrenchmark charts/wrenchmark -f values-prod.yaml -n atero
```

## 8. Uninstall

```bash
helm uninstall wrenchmark -n atero

# Clean up secrets (if needed)
kubectl delete secret wrenchmark-db wrenchmark-gemini -n atero
```

## Troubleshooting

### Pod CrashLoopBackOff

```bash
# Check logs
kubectl logs -n atero <pod-name>

# Check events
kubectl describe pod -n atero <pod-name>

# Common issues:
# - Database connection string incorrect
# - Gemini credentials missing or invalid
# - Image pull failure (check imagePullSecrets)
```

### Database Connection Fails

```bash
# Verify secret exists and has correct key
kubectl get secret -n atero wrenchmark-db -o jsonpath='{.data.connection-string}' | base64 -d

# Test connection from pod
kubectl exec -it -n atero <pod-name> -- env | grep DB_CONNECTION_STRING
```

### Ingress Not Working

```bash
# Check ingress status
kubectl describe ingress -n atero wrenchmark

# Check ingress controller logs
kubectl logs -n ingress-nginx -l app.kubernetes.io/component=controller

# Test services directly
kubectl port-forward -n atero svc/wrenchmark-wrenchmark-frontend 8080:80
curl http://localhost:8080/health
```

## Common Commands

```bash
# List all releases
helm list -n atero

# Get release status
helm status wrenchmark -n atero

# Get rendered values
helm get values wrenchmark -n atero

# Get all rendered manifests
helm get manifest wrenchmark -n atero

# Rollback
helm rollback wrenchmark <revision> -n atero

# History
helm history wrenchmark -n atero
```

## Next Steps

- Configure TLS/HTTPS with cert-manager
- Set up monitoring with Prometheus
- Configure autoscaling (HPA)
- Set up backup for database
- Configure resource limits based on load testing
- Add pod disruption budgets for HA

For more details, see [README.md](README.md).
