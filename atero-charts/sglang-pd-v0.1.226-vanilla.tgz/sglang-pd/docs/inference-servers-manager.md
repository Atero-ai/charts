# Inference Servers Manager

The Inference Servers Manager is a component that runs alongside SGLang PD deployments when using the `atero-gw` routing mode. It manages the lifecycle of inference server registrations in etcd and performs periodic pod restarts to maintain system health.

## When It Runs

The manager is deployed only when all these conditions are met:
- `ateroDeployment.enabled: true`
- `ateroDeployment.routingMode: "atero-gw"`
- `inferenceServersManager.enabled: true`

## What It Does

The manager runs two concurrent loops:

### 1. Sync Loop (etcd Registration)

Keeps etcd registrations in sync with pod readiness state:

- **Monitors** all prefill and decode pods via Kubernetes API
- **Registers** pods in etcd when:
  - Pod is in `Running` phase
  - Pod has `Ready` condition = `True`
  - Pod has been ready for at least `stabilizationDelay` seconds (default: 120s)
  - Pod is not blacklisted (being restarted)
- **Unregisters** pods from etcd when:
  - Pod is no longer Ready
  - Pod is blacklisted for restart
  - Pod no longer exists
- Uses `atero_etcd_cli load --keep-alive` for registration (maintains lease)
- Uses `atero_etcd_cli cleanup` for unregistration
- Runs every `checkInterval` seconds (default: 10s)

### 2. Restart Loop (Pod Recycling)

Periodically restarts the oldest prefill pod to prevent memory fragmentation and ensure fresh state:

- **Checks** every `checkInterval` seconds (default: 10s)
- **Criteria** for restart:
  - Enough stable prefill pods must exist to maintain `minPrefillersRatio` capacity after the restart
  - No other restart is currently in progress
  - The oldest pod must be at least `minPodAge` seconds old (default: 600s / 10 minutes)
- **Restart procedure**:
  1. Add pod to blacklist (sync loop will unregister from etcd)
  2. Wait `drainTime` seconds (default: 120s / 2 minutes) for in-flight requests
  3. Delete the pod (StatefulSet will recreate it)
  4. Remove from blacklist (sync loop will re-register when new pod stabilizes)

## Configuration

All settings are in `values.yaml` under `inferenceServersManager`:

```yaml
inferenceServersManager:
  enabled: true

  # Enable periodic pod restarts to prevent memory fragmentation
  # When false, only sync loop runs (etcd registration) - no pod restarts
  enableRestartingPods: true

  # Time (seconds) a pod must be Ready before being registered in etcd
  # Prevents registering pods that are still warming up
  stabilizationDelay: 120

  # Time (seconds) to wait after removing a pod from etcd before deleting it
  # Allows in-flight requests to complete
  drainTime: 120

  # Minimum age (seconds) of a prefill pod before it's eligible for restart
  # Only the oldest pod (if older than this) will be restarted
  minPodAge: 600  # 10 minutes

  # Minimum interval (seconds) between consecutive restarts
  # For 4-hour cycle with 15 pods: 14400/15 = 960s (16 min)
  # Set to 0 to disable (restarts happen as fast as possible)
  restartInterval: 960

  # Minimum ratio (0.0-1.0) of expected prefill pods that must remain stable after restart
  # Computed as: minPrefillers = ceil(minPrefillersRatio * prefill.replicas)
  # Examples with prefill.replicas=15:
  # - 0.7 (default): ceil(0.7 * 15) = 11 minimum, need 12/15 stable to restart
  # - 0.8: need 13/15 stable to restart
  # - 0.5: need 9/15 stable to restart
  minPrefillersRatio: 0.7

  # Interval (seconds) between loop iterations (sync and restart loops)
  checkInterval: 10

  # Log level: DEBUG, INFO, WARNING, ERROR
  logLevel: "INFO"
```

## etcd Keys Created

For each registered server, the following etcd keys are created:

- `/catalog/{model_name}` - Model catalog entry
- `/models/{model_alias}/{server_address}` - Server entry under model
- `/inference/{server_address}/0` - Inference endpoint

Example for a prefill pod (using pod IP address):
```
/catalog/nvidia/DeepSeek-V3-0324-NVFP4
/models/nvidia/DeepSeek-V3-0324-NVFP4/10.244.1.15:30000
/inference/10.244.1.15:30000/0
```

## Understanding minPrefillersRatio

The manager reads the expected prefiller count from `prefill.replicas` and computes the minimum stable pods required:

```
minPrefillers = ceil(minPrefillersRatio × prefill.replicas)
```

The `minPrefillersRatio` setting controls what fraction of capacity must remain stable after a restart:

| minPrefillersRatio | With prefill.replicas=15 | Min stable after restart | Need stable to restart |
|--------------------|--------------------------|--------------------------|------------------------|
| 0.7 (default) | ceil(10.5) = 11 | 11 | 12/15 (80%) |
| 0.8 | ceil(12) = 12 | 12 | 13/15 (87%) |
| 0.5 | ceil(7.5) = 8 | 8 | 9/15 (60%) |
| 1.0 | 15 | 15 | Never (impossible) |

The default of 0.7 means "keep at least 70% of prefillers stable after restart". This allows restarting pods even when some are still warming up, speeding up the restart cycle while maintaining reasonable capacity.

## Troubleshooting

### Check Manager Logs

```bash
kubectl logs -l app.kubernetes.io/component=servers-manager -f
```

### Verify etcd Registrations

```bash
kubectl exec -it <etcd-pod> -- etcdctl get --prefix /
```

### Check Manager Pod Status

```bash
kubectl get pods -l app.kubernetes.io/component=servers-manager
kubectl describe pod <manager-pod-name>
```

### Common Issues

1. **Pod not registering**: Check if pod has been Ready for at least `stabilizationDelay` seconds
2. **Manager OOM**: The manager runs `atero_etcd_cli` processes that load vLLM plugins. Default memory limit is 64Gi.
3. **Wrong architecture**: Manager image is amd64-only. Template includes `kubernetes.io/arch: amd64` nodeSelector.

## Architecture Notes

- Runs as a single-replica Deployment (not HA)
- Uses Kubernetes ServiceAccount with pod list/watch/delete permissions
- Spawns long-running `atero_etcd_cli` subprocesses with `--keep-alive` for each registered server
- Thread-safe: sync loop and restart loop share blacklist via lock
