{{/*
Expand the name of the chart.
*/}}
{{- define "sglang-pd.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "sglang-pd.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "sglang-pd.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "sglang-pd.labels" -}}
helm.sh/chart: {{ include "sglang-pd.chart" . }}
{{ include "sglang-pd.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "sglang-pd.selectorLabels" -}}
app.kubernetes.io/name: {{ include "sglang-pd.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Volumes for model storage based on model artifact prefix
*/}}
{{- define "sglang-pd.modelVolume" -}}
{{- $parsedArtifacts := regexSplit "://" .uri -1 -}}
{{- $protocol := first $parsedArtifacts -}}
{{- $path := last $parsedArtifacts -}}
{{- if eq $protocol "hf" -}}
- name: model-storage
  emptyDir:
    sizeLimit: {{ default "0" .size }}
{{- else if eq $protocol "pvc" }}
{{- $parsedPath := regexSplit "/" $path -1 -}}
{{- $claim := first $parsedPath -}}
- name: model-storage
  persistentVolumeClaim:
    claimName: {{ $claim }}
{{- else if eq $protocol "fs" }}
- name: model-storage
  hostPath:
    path: {{ printf "/%s" $path | quote }}
    type: Directory
{{- end }}
{{- end }}

{{/*
Common volumes for worker pods
*/}}
{{- define "sglang-pd.workerVolumes" -}}
- name: shm-expanded
  emptyDir:
    medium: Memory
    sizeLimit: {{ .Values.volumes.shm.sizeLimit | quote }}
- name: dev-shm
  hostPath:
    path: {{ .Values.volumes.hostPaths.devShm }}
    type: DirectoryOrCreate
{{- if .Values.volumes.hostPaths.gdrdrv.enabled }}
- name: gdrdrv
  hostPath:
    path: {{ .Values.volumes.hostPaths.gdrdrv.path | quote }}
{{- end }}
- name: host-ib
  hostPath:
    path: {{ .Values.volumes.hostPaths.infiniband }}
- name: host-dev
  hostPath:
    path: {{ .Values.volumes.hostPaths.dev }}
- name: host-sys
  hostPath:
    path: {{ .Values.volumes.hostPaths.sys }}
{{- include "sglang-pd.modelVolume" .Values.model.artifacts | nindent 0 }}
{{- end }}

{{/*
Common volume mounts for worker containers
*/}}
{{- define "sglang-pd.workerVolumeMounts" -}}
- name: shm-expanded
  mountPath: /dev/shm
- name: dev-shm
  mountPath: /sock/
{{- if .Values.volumes.hostPaths.gdrdrv.enabled }}
- name: gdrdrv
  mountPath: /dev/gdrdrv
{{- end }}
- name: model-storage
  mountPath: /models
  subPath: models
- name: host-ib
  mountPath: /dev/infiniband
- name: host-dev
  mountPath: /dev
- name: host-sys
  mountPath: /sys
{{- end }}

{{/*
Common environment variables for worker containers
*/}}
{{- define "sglang-pd.workerEnv" -}}
{{- if .Values.model.hfTokenSecretName }}
- name: HF_TOKEN
  valueFrom:
    secretKeyRef:
      name: {{ .Values.model.hfTokenSecretName }}
      key: HF_TOKEN
{{- end }}
- name: HF_HOME
  value: /models
- name: SGLANG_LOG_LEVEL
  value: {{ .Values.common.logLevel | quote }}
- name: SGLANG_DG_CACHE_DIR
  value: {{ .Values.common.dgCacheDir | default "/models/deepgem_warmup" | quote }}
{{- end }}

{{/*
Generate prefill worker URLs for router
*/}}
{{- define "sglang-pd.prefillUrls" -}}
{{- $fullname := include "sglang-pd.fullname" . -}}
{{- $basePort := int .Values.common.port -}}
{{- $urls := list -}}
{{- range $i := until (int .Values.prefill.replicas) -}}
{{- $port := add $basePort $i -}}
{{- $urls = append $urls (printf "http://%s-prefill-%d.%s-prefill:%d" $fullname $i $fullname $port) -}}
{{- end -}}
{{- join "," $urls -}}
{{- end }}

{{/*
Generate decode worker URLs for router
*/}}
{{- define "sglang-pd.decodeUrls" -}}
{{- $fullname := include "sglang-pd.fullname" . -}}
{{- $basePort := add (int .Values.common.port) (int .Values.prefill.replicas) -}}
{{- $urls := list -}}
{{- range $i := until (int .Values.decode.replicas) -}}
{{- $port := add $basePort $i -}}
{{- $urls = append $urls (printf "http://%s-decode-%d.%s-decode:%d" $fullname $i $fullname $port) -}}
{{- end -}}
{{- join "," $urls -}}
{{- end }}

{{/*
Get port for a specific prefill worker index
*/}}
{{- define "sglang-pd.prefillPort" -}}
{{- add (int .basePort) (int .index) -}}
{{- end }}

{{/*
Get port for a specific decode worker index
*/}}
{{- define "sglang-pd.decodePort" -}}
{{- add (add (int .basePort) (int .prefillReplicas)) (int .index) -}}
{{- end }}

{{/*
Worker command and args for sglang server.
Pass: dict "root" $ "worker" $.Values.decode "mode" "decode" "port" $port
*/}}
{{- define "sglang-pd.workerCommand" -}}
{{- $root := .root -}}
{{- $worker := .worker -}}
{{- $mode := .mode -}}
{{- $port := .port -}}
{{- if $root.Values.manualDeploy }}
command: ["bash", "-c", "trap : TERM INT; sleep infinity & wait"]
{{- else }}
command: ["bash", "-c"]
args:
- |
  {{- if $root.Values.common.preStartCommand }}
  # Run common pre-start command
  {{- $root.Values.common.preStartCommand | nindent 2 }}
  {{- end }}
  {{- if $worker.preStartCommand }}
  # Run {{ $mode }} pre-start command
  {{- $worker.preStartCommand | nindent 2 }}
  {{- end }}
  # Start sglang {{ $mode }} server
  {{- if $root.Values.model.numaBind.enabled }}
  exec numactl --cpunodebind={{ $root.Values.model.numaBind.cpuNodeBind }} --membind={{ $root.Values.model.numaBind.memBind }} python -m sglang.launch_server \
  {{- else }}
  exec python -m sglang.launch_server \
  {{- end }}
  --model {{ $root.Values.model.name | quote }} \
  {{- if $root.Values.model.servedModelName }}
  --served-model-name {{ $root.Values.model.servedModelName | quote }} \
  {{- end }}
  --host 0.0.0.0 \
  --port {{ $port | quote }} \
  --mem-fraction-static {{ $root.Values.common.memFractionStatic | quote }} \
  --tp-size {{ $root.Values.common.tensorParallelism | quote }} \
  --disaggregation-ib-device {{ $root.Values.common.disaggregationIBDevice | quote }} \
  --disaggregation-mode {{ $mode | quote }} \
  {{- if $root.Values.common.watchdogTimeout }}
  --watchdog-timeout {{ $root.Values.common.watchdogTimeout | quote }} \
  {{- end }}
  {{- if $root.Values.model.enableMetrics }}
  --enable-metrics \
  --collect-tokens-histogram \
  {{- end }}
  {{- if $root.Values.model.enableCacheReport }}
  --enable-cache-report \
  {{- end }}
  {{- with $root.Values.common.extraArgs }}
  {{- range . }}
  {{ . }} \
  {{- end }}
  {{- end }}
  {{- with $worker.extraArgs }}
  {{- range . }}
  {{ . }} \
  {{- end }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Get etcd endpoint hostname
*/}}
{{- define "sglang-pd.etcdHost" -}}
{{- if .Values.ateroDeployment.etcd.endpoint -}}
{{- .Values.ateroDeployment.etcd.endpoint }}
{{- else -}}
{{- printf "%s-%s" .Values.ateroDeployment.ateroDeploymentReleaseName "etcd" | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
