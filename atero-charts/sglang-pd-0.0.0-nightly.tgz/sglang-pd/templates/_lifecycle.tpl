{{/*
Lifecycle manager sidecar for etcd registration
Parameters:
  - .root: root context ($)
  - .port: worker port
  - .inferenceType: "prefill" or "decode" or "" (for router)
  - .componentName: "prefill-0", "decode-1", "sglang-router", etc.
  - .workerIndex: optional worker index (for remote worker, constructs DNS name)
*/}}
{{- define "sglang-pd.lifecycleManager" -}}
{{- $etcdHost := include "sglang-pd.etcdHost" .root }}
{{- $fullname := include "sglang-pd.fullname" .root }}
{{- $workerHost := "" }}
{{- if hasKey . "workerIndex" }}
  {{- if eq .inferenceType "prefill" }}
    {{- $workerHost = printf "%s-prefill-%d-0.%s-prefill.%s.svc.cluster.local" $fullname (int .workerIndex) $fullname .root.Release.Namespace }}
  {{- else if eq .inferenceType "decode" }}
    {{- $workerHost = printf "%s-decode-%d-0.%s-decode.%s.svc.cluster.local" $fullname (int .workerIndex) $fullname .root.Release.Namespace }}
  {{- end }}
{{- end }}
- name: {{ .componentName }}-lifecycle-manager
  image: "{{ .root.Values.ateroImage.repository }}:{{ .root.Values.ateroImage.tag }}"
  startupProbe:
    exec:
      command:
        - /bin/sh
        - -c
        - |
          # Check model health
          {{- if $workerHost }}
          curl -v --fail http://{{ $workerHost }}:{{ .port }}/health && \
          {{- else }}
          curl -v --fail http://localhost:{{ .port }}/health && \
          {{- end }}
          # Check etcd availability - pod won't start until both model and etcd are ready
          curl -v --fail http://{{ $etcdHost }}:{{ .root.Values.ateroDeployment.etcd.port }}/health
    periodSeconds: 10
    timeoutSeconds: 10
    failureThreshold: 120
  livenessProbe:
    exec:
      command:
        - /bin/sh
        - -c
        - |
          # Check model health
          {{- if $workerHost }}
          curl -v --fail http://{{ $workerHost }}:{{ .port }}/health && \
          {{- else }}
          curl -v --fail http://localhost:{{ .port }}/health && \
          {{- end }}
          # Check etcd availability - if etcd is down, pod should restart to re-register
          curl -v --fail http://{{ $etcdHost }}:{{ .root.Values.ateroDeployment.etcd.port }}/health
    initialDelaySeconds: 5
    periodSeconds: 5
    timeoutSeconds: 5
    failureThreshold: 15
  command: ["/bin/sh", "-c"]
  args:
    - |
      set -x
      {{- if $workerHost }}
      WORKER_HOST_DNS="{{ $workerHost }}"
      echo "Waiting for {{ .componentName }} worker at ${WORKER_HOST_DNS}:{{ .port }} to be ready..."
      until curl -s -f http://${WORKER_HOST_DNS}:{{ .port }}/health; do
        echo "{{ .componentName | title }} worker not ready yet, sleeping..."
        sleep 5
      done
      # Resolve DNS to IP for etcd registration with retries
      sleep 10
      WORKER_HOST=""
      for i in $(seq 1 50); do
        WORKER_HOST=$(getent hosts ${WORKER_HOST_DNS} | awk '{ print $1 }' | head -n1)
        if [ -n "$WORKER_HOST" ]; then
          echo "Successfully resolved ${WORKER_HOST_DNS} to IP: ${WORKER_HOST} (attempt $i)"
          break
        fi
        echo "Attempt $i: Failed to resolve ${WORKER_HOST_DNS}, retrying..."
        sleep 1
      done
      if [ -z "$WORKER_HOST" ]; then
        echo "Failed to resolve ${WORKER_HOST_DNS} to IP after 50 attempts, falling back to DNS name"
        WORKER_HOST="${WORKER_HOST_DNS}"
      fi
      echo "Using worker IP: ${WORKER_HOST}"
      # Save IP to file for preStop hook
      echo "${WORKER_HOST}" > /tmp/worker_ip.txt
      {{- else }}
      echo "Waiting for sglang {{ .componentName }} worker to be ready..."
      until curl -s -f http://localhost:{{ .port }}/health; do
        echo "{{ .componentName | title }} worker not ready yet, sleeping..."
        sleep 5
      done
      # Get the pod's IP address
      WORKER_HOST=$(hostname -i)
      {{- end }}

      echo "{{ .componentName | title }} worker is ready. Starting etcd registration..."
      /venv/bin/atero_etcd_cli \
        --endpoint "{{ $etcdHost }}:{{ .root.Values.ateroDeployment.etcd.port }}" \
        load \
        --model "{{ .root.Values.model.name }}" \
        --model-alias "{{ default .root.Values.model.name .root.Values.model.servedModelName }}" \
        --servers "${WORKER_HOST}:{{ .port }}" \
        --backend "sglang" \
        {{- if .inferenceType }}
        --inference-type "{{ .inferenceType }}" \
        {{- end }}
        {{- if .root.Values.model.catalogParams.throttling.enabled }}
        --throttle-factor {{ .root.Values.model.catalogParams.throttling.throttleFactor }} \
        {{- end }}
        {{- if .root.Values.model.catalogParams.maxRequestsPerInstance.enabled }}
        {{- if .root.Values.model.catalogParams.maxRequestsPerInstance.defaultTier }}
        --max-requests-default-tier {{ .root.Values.model.catalogParams.maxRequestsPerInstance.defaultTier }} \
        {{- end }}
        {{- if .root.Values.model.catalogParams.maxRequestsPerInstance.serviceTier }}
        --max-requests-service-tier {{ .root.Values.model.catalogParams.maxRequestsPerInstance.serviceTier }} \
        {{- end }}
        {{- end }}
        {{- if and .root.Values.model.catalogParams.throttling.enabled .root.Values.model.catalogParams.throttling.ttftCoefficients }}
        --ttft-coefficients {{ join " " .root.Values.model.catalogParams.throttling.ttftCoefficients }} \
        {{- end }}
        {{- if .root.Values.model.catalogParams.gpuBlocks }}
        --gpu-blocks {{ .root.Values.model.catalogParams.gpuBlocks }} \
        {{- end }}
        --ttl {{ .root.Values.ateroDeployment.etcd.leaseTTL | default 60 }} \
        --keep-alive
  lifecycle:
    preStop:
      exec:
        command:
          - /bin/sh
          - -c
          - |
            {{- if $workerHost }}
            # Read worker IP from file saved during startup
            WORKER_HOST=$(cat /tmp/worker_ip.txt)
            echo "Using worker IP from file: ${WORKER_HOST}"
            {{- else }}
            WORKER_HOST=$(hostname -i)
            {{- end }}
            echo "Cleaning up etcd registration via atero_etcd_cli..."
            /venv/bin/atero_etcd_cli \
              --endpoint "{{ $etcdHost }}:{{ .root.Values.ateroDeployment.etcd.port }}" \
              cleanup \
              --model-alias "{{ default .root.Values.model.name .root.Values.model.servedModelName }}" \
              --servers "${WORKER_HOST}:{{ .port }}" || true
            echo "Cleanup complete or timed out"
{{- end }}
