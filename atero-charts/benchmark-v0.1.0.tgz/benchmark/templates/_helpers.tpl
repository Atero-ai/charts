{{/*
Expand the name of the chart.
*/}}
{{- define "benchmark.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "benchmark.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "benchmark.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "benchmark.labels" -}}
helm.sh/chart: {{ include "benchmark.chart" . }}
{{ include "benchmark.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "benchmark.selectorLabels" -}}
app.kubernetes.io/name: {{ include "benchmark.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Validate performance configuration
NOTE: We only validate that required fields are present, not mutual exclusivity.
Helm value merging makes strict mutual exclusivity impractical - both sections may exist in merged values.
The config-schema.json enforces mutual exclusivity at the JSON schema level.
*/}}
{{- define "benchmark.validatePerformanceConfig" -}}
{{- $bt := .Values.performance.benchmarkType -}}
{{- if eq $bt "serving" -}}
  {{- if not .Values.performance.serving -}}
    {{- fail "ERROR: performance.benchmarkType is 'serving' but performance.serving configuration is missing. Add performance.serving section to values.yaml." -}}
  {{- end -}}
  {{- if not .Values.performance.serving.datasetName -}}
    {{- fail "ERROR: performance.serving.datasetName is REQUIRED when benchmarkType is 'serving'. Set performance.serving.datasetName in values.yaml." -}}
  {{- end -}}
{{- else if eq $bt "simple" -}}
  {{- if not .Values.performance.simple -}}
    {{- fail "ERROR: performance.benchmarkType is 'simple' but performance.simple configuration is missing. Add performance.simple section to values.yaml." -}}
  {{- end -}}
  {{- if not .Values.performance.simple.modelAddress -}}
    {{- fail "ERROR: performance.simple.modelAddress is REQUIRED when benchmarkType is 'simple'. Set performance.simple.modelAddress in values.yaml." -}}
  {{- end -}}
{{- else -}}
  {{- fail (printf "ERROR: Invalid performance.benchmarkType: '%s'. Must be either 'serving' or 'simple'." $bt) -}}
{{- end -}}
{{- end -}}
