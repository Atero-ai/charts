{{/*
Chart name, truncated to 63 characters.
*/}}
{{- define "nemotron-voicechat.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Fully qualified app name, truncated to 63 characters.
*/}}
{{- define "nemotron-voicechat.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart label value.
*/}}
{{- define "nemotron-voicechat.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Standard Kubernetes labels.
*/}}
{{- define "nemotron-voicechat.labels" -}}
helm.sh/chart: {{ include "nemotron-voicechat.chart" . }}
{{ include "nemotron-voicechat.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels.
*/}}
{{- define "nemotron-voicechat.selectorLabels" -}}
app.kubernetes.io/name: {{ include "nemotron-voicechat.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Model storage volume based on artifact URI prefix.
Context is .Values.model.artifacts
*/}}
{{- define "nemotron-voicechat.modelVolume" -}}
{{- $parsedArtifacts := regexSplit "://" .uri -1 -}}
{{- $protocol := first $parsedArtifacts -}}
{{- $path := last $parsedArtifacts -}}
{{- if eq $protocol "pvc" }}
{{- $parsedPath := regexSplit "/" $path -1 -}}
{{- $claim := first $parsedPath -}}
- name: model-storage
  persistentVolumeClaim:
    claimName: {{ $claim }}
{{- else if eq $protocol "fs" }}
- name: model-storage
  hostPath:
    path: {{ printf "/%s" $path | quote }}
    type: Directory
{{- end }}
{{- end }}

{{/*
Model storage mount path derived from artifact URI.
*/}}
{{- define "nemotron-voicechat.modelMountPath" -}}
{{- $parsedArtifacts := regexSplit "://" .uri -1 -}}
{{- $protocol := first $parsedArtifacts -}}
{{- $path := last $parsedArtifacts -}}
{{- if eq $protocol "fs" -}}
/{{ $path }}
{{- else -}}
/models
{{- end -}}
{{- end -}}
