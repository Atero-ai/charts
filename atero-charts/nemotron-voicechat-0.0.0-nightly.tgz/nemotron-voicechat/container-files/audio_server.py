#!/usr/bin/env python3
"""
Nemotron VoiceChat Server - Audio WebSocket with Triton Inference
Handles real-time audio streaming from clients and processes through Triton
Uses FastAPI for WebSocket handling
"""

import asyncio
import base64
import json
import logging
import os
import time
import uuid
from contextlib import asynccontextmanager
from typing import Optional

import numpy as np
import soundfile
import tritonclient.http.aio as httpclient
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from scipy import signal
from scipy.signal import resample_poly
from sphn import OpusStreamReader, OpusStreamWriter
from tritonclient.utils import np_to_triton_dtype

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Audio configuration
INPUT_OPUS_SAMPLE_RATE = 24000  # Client records at 24kHz for Opus compatibility
INPUT_SAMPLE_RATE = 16000  # Model expects 16kHz
MODEL_OUTPUT_SAMPLE_RATE = 22050  # Triton model outputs at 22050Hz
OUTPUT_SAMPLE_RATE = 24000  # Opus encoding at 24kHz (Opus works best with 8k, 12k, 16k, 24k, 48k)
INPUT_AUDIO_FORMAT = "opus"  # Use Opus for receiving from client
OUTPUT_AUDIO_FORMAT = "opus"  # Use Opus for transmission
AUDIO_FORMAT = "pcm16"  # Internal processing format
BYTES_PER_SAMPLE = 2
CHANNELS = 1
OPUS_FRAME_DURATION_MS = 20  # 20ms frames (480 samples at 24kHz)
OPUS_BITRATE = 24000  # 24 kbps - good quality for speech

# Triton configuration
TRITON_URL = "localhost:8000"  # Update with your Triton server URL
TRITON_MODEL_NAME = "nemotron-voicechat"  # Update with your model name

# Real-time processing configuration
TRITON_CHUNK_DURATION_SECS = 0.08  # 80ms per Triton inference chunk
MAX_QUEUE_SIZE = (
    5  # Maximum chunks to buffer (5 chunks = ~400ms latency, allows for network delays)
)
ENABLE_QUEUE_MONITORING = True  # Log when queue is backing up
NUM_CHUNKS_PER_INFERENCE = 1  # Number of 80ms chunks to buffer before Triton inference (2 = 160ms)


class TritonClientManager:
    """Manages Triton client connection"""

    def __init__(self):
        self.client: Optional[httpclient.InferenceServerClient] = None
        self.url = TRITON_URL

    async def get_client(self) -> httpclient.InferenceServerClient:
        """Get or create Triton client"""
        if self.client is None:
            logger.info(f"Creating Triton client for {self.url}")
            self.client = httpclient.InferenceServerClient(url=self.url, verbose=False)

            try:
                is_ready = await self.client.is_server_ready()
                if not is_ready:
                    raise Exception(f"Triton server at {self.url} is not ready")
                logger.info("Triton server is ready")
            except Exception as e:
                logger.error(f"Failed to connect to Triton: {e}")
                await self.client.close()
                self.client = None
                raise

        return self.client

    async def close(self):
        """Close Triton client"""
        if self.client:
            await self.client.close()
            self.client = None


# Global Triton client manager
triton_manager = TritonClientManager()


class TritonSequenceManager:
    """Manages a pre-warmed Triton sequence so clients get instant response"""

    _WARMUP_WAV_PATH = "/s2s/warmup_audio.wav"

    ACQUIRE_TIMEOUT_SECS = 20

    def __init__(self):
        self._ready_sequence_future: Optional[asyncio.Future[int]] = None

    @staticmethod
    def _load_warmup_chunks() -> list[np.ndarray]:
        """Load warmup audio from WAV file and split into 80ms chunks."""
        audio, sample_rate = soundfile.read(TritonSequenceManager._WARMUP_WAV_PATH, dtype="float32")
        if audio.ndim > 1:
            audio = audio[:, 0]
        if sample_rate != INPUT_SAMPLE_RATE:
            audio = resample_poly(audio, INPUT_SAMPLE_RATE, sample_rate).astype(np.float32)
        chunk_size = int(INPUT_SAMPLE_RATE * TRITON_CHUNK_DURATION_SECS)  # 1280 samples
        chunks = []
        for i in range(0, len(audio), chunk_size):
            chunk = audio[i : i + chunk_size]
            if len(chunk) < chunk_size:
                chunk = np.pad(chunk, (0, chunk_size - len(chunk)))
            chunks.append(chunk.reshape(1, -1))
        return chunks

    async def _warm_up_impl(self):
        """Pre-warm a Triton sequence. Logs and re-raises on failure."""
        sequence_id = int(uuid.uuid4().int & 0xFFFFFFFF)
        warmup_chunks = self._load_warmup_chunks()
        logger.info(
            f"TritonSequenceManager: Starting warmup for sequence_id={sequence_id} ({len(warmup_chunks)} chunks of audio)..."
        )
        warmup_start = time.time()

        try:
            client = await triton_manager.get_client()

            outputs = [
                httpclient.InferRequestedOutput("output_text"),
                httpclient.InferRequestedOutput("output_asr_text"),
                httpclient.InferRequestedOutput("output_audio"),
            ]

            for i, chunk in enumerate(warmup_chunks):
                inputs = [
                    httpclient.InferInput(
                        "audio_signal", chunk.shape, np_to_triton_dtype(chunk.dtype)
                    )
                ]
                inputs[0].set_data_from_numpy(chunk)

                await client.infer(
                    model_name=TRITON_MODEL_NAME,
                    inputs=inputs,
                    outputs=outputs,
                    request_id=str(uuid.uuid4()),
                    sequence_id=sequence_id,
                    sequence_start=(i == 0),
                    sequence_end=False,
                )
        except Exception as e:
            logger.error(f"TritonSequenceManager: Failed to warm up: {e}")
            raise

        warmup_time = time.time() - warmup_start
        logger.info(f"TritonSequenceManager: Sequence {sequence_id} ready in {warmup_time:.3f}s")
        return sequence_id

    def warm_up(self):
        """Start pre-warming a sequence as a background task.

        Since triton with the nemotron voicechat model can only process
        one sequence at a time, we don't warm up if there is an ongoing warmup
        or if there is a ready sequence.
        """
        if self._ready_sequence_future is None:
            self._ready_sequence_future = asyncio.ensure_future(self._warm_up_impl())

    async def get_seq_id(self) -> int:
        """Wait for a warmed sequence_id to become available.

        Raises TimeoutError if no sequence is ready within ACQUIRE_TIMEOUT_SECS.
        Propagates warmup errors if warmup failed.
        """
        if self._ready_sequence_future is None:
            raise RuntimeError("No warmup had been started")
        seq_id = await asyncio.wait_for(
            self._ready_sequence_future, timeout=self.ACQUIRE_TIMEOUT_SECS
        )
        self._ready_sequence_future = None
        return seq_id


# Global triton sequence manager
triton_sequence_manager = TritonSequenceManager()


class AudioSession:
    """Represents an audio streaming session for a client"""

    def __init__(self, client_id: str, websocket: WebSocket):
        self.client_id = client_id
        self.websocket = websocket
        self.chunks_received = 0
        self.chunks_sent = 0
        self.chunks_dropped = 0
        self.sequence_id = int(uuid.uuid4().int & 0xFFFFFFFF)  # 32-bit sequence ID
        self.triton_client: Optional[httpclient.InferenceServerClient] = None
        self.inference_queue: asyncio.Queue = asyncio.Queue(maxsize=MAX_QUEUE_SIZE)
        self.inference_task: Optional[asyncio.Task] = None
        self.send_task: Optional[asyncio.Task] = None
        self.running = True

        # Initialize Opus stream writer for output compression
        self.opus_writer = OpusStreamWriter(OUTPUT_SAMPLE_RATE)
        # Buffer for Opus encoding (need to send in valid frame sizes)
        self.opus_encode_buffer = np.array([], dtype=np.float32)
        self.opus_frame_size = 1920  # 80ms at 24kHz

        # Buffer for Triton inference (accumulate NUM_CHUNKS_PER_INFERENCE chunks)
        self.triton_input_buffer = np.array([], dtype=np.float32)
        self.triton_chunk_size = int(
            INPUT_SAMPLE_RATE * TRITON_CHUNK_DURATION_SECS
        )  # 80ms at 16kHz = 1280 samples
        self.triton_inferences = 0  # Track number of inferences sent
        # Initialize Opus stream reader for input decompression (24kHz)
        self.opus_reader = OpusStreamReader(INPUT_OPUS_SAMPLE_RATE)

        # Accumulated transcripts
        self.accumulated_user_transcript = []
        self.accumulated_agent_transcript = []

    def encode_to_opus(self, audio_float32: np.ndarray) -> None:
        """
        Encode audio to Opus with proper frame buffering.
        Encoded data will be read by send_loop via opus_writer.read_bytes()

        Args:
            audio_float32: Float32 audio normalized to [-1.0, 1.0]
        """
        # Flatten to 1D
        if audio_float32.ndim > 1:
            audio_float32 = audio_float32.flatten()

        # Add to buffer
        self.opus_encode_buffer = np.concatenate([self.opus_encode_buffer, audio_float32])

        # Encode complete frames (don't read bytes - send_loop will do that)
        while len(self.opus_encode_buffer) >= self.opus_frame_size:
            # Extract one frame (1920 samples = 80ms at 24kHz)
            frame = self.opus_encode_buffer[: self.opus_frame_size]
            self.opus_encode_buffer = self.opus_encode_buffer[self.opus_frame_size :]

            # Encode frame - opus_writer buffers the encoded data internally
            self.opus_writer.append_pcm(frame)

    async def queue_audio_chunk(self, audio_data: str, event_id: str = None):
        """Queue audio chunk for async processing with real-time dropping"""
        self.chunks_received += 1

        # Check queue size for monitoring
        queue_size = self.inference_queue.qsize()

        if ENABLE_QUEUE_MONITORING and queue_size >= MAX_QUEUE_SIZE - 2:
            logger.warning(
                f"Client {self.client_id}: Queue nearly full ({queue_size}/{MAX_QUEUE_SIZE}), "
                f"processing may be delayed"
            )

        try:
            # Try to add to queue without blocking
            self.inference_queue.put_nowait((audio_data, event_id))

        except asyncio.QueueFull:
            # Queue is full - drop oldest chunk and add new one (real-time processing)
            try:
                # Remove oldest chunk
                self.inference_queue.get_nowait()
                self.chunks_dropped += 1

                # Add new chunk
                self.inference_queue.put_nowait((audio_data, event_id))

                if self.chunks_dropped % 10 == 1:  # Log every 10th drop
                    logger.warning(
                        f"Client {self.client_id}: Dropped {self.chunks_dropped} chunks to maintain real-time processing"
                    )

            except Exception as e:
                logger.error(f"Client {self.client_id}: Error managing queue: {e}")

    async def start_inference_worker(self):
        """Start background worker to process audio chunks"""
        logger.info(f"Client {self.client_id}: Starting inference worker")
        self.inference_task = asyncio.create_task(self._inference_worker())
        # Start send loop for sending encoded audio
        self.send_task = asyncio.create_task(self._send_loop())

    async def stop_inference_worker(self):
        """Stop background inference worker and send loop"""
        self.running = False
        if self.inference_task and not self.inference_task.done():
            self.inference_task.cancel()
            try:
                await self.inference_task
            except asyncio.CancelledError:
                pass
        if self.send_task and not self.send_task.done():
            self.send_task.cancel()
            try:
                await self.send_task
            except asyncio.CancelledError:
                pass

    async def _send_loop(self):
        """Background loop to continuously send encoded audio to client"""
        logger.info(f"Client {self.client_id}: Send loop started")

        try:
            while self.running:
                # Read ALL available encoded audio before sleeping
                sent_any = False
                while self.running:
                    opus_data = self.opus_writer.read_bytes()

                    if len(opus_data) == 0:
                        break  # No more data available

                    sent_any = True

                    # Encode as base64
                    opus_base64 = base64.b64encode(opus_data).decode("utf-8")

                    # Send to client
                    response_msg = {
                        "type": "response.output_audio.delta",
                        "event_id": str(uuid.uuid4()),
                        "delta": opus_base64,
                    }

                    try:
                        await asyncio.wait_for(
                            self.websocket.send_text(json.dumps(response_msg)), timeout=2.0
                        )
                        self.chunks_sent += 1

                        if self.chunks_sent % 50 == 0:
                            logger.info(
                                f"Client {self.client_id}: Sent {self.chunks_sent} audio packets"
                            )
                    except asyncio.TimeoutError:
                        logger.warning(f"Client {self.client_id}: Send timeout in send_loop")
                    except Exception as e:
                        if self.running:
                            logger.error(f"Client {self.client_id}: Error in send_loop: {e}")
                        break

                # Only sleep if no data was sent (avoid busy loop when idle)
                if not sent_any:
                    await asyncio.sleep(0.001)  # 1ms poll interval when idle

        except asyncio.CancelledError:
            logger.info(f"Client {self.client_id}: Send loop cancelled")
        except Exception as e:
            logger.error(f"Client {self.client_id}: Send loop error: {e}", exc_info=True)
        finally:
            logger.info(f"Client {self.client_id}: Send loop stopped")

    async def _inference_worker(self):
        """Background worker that processes audio chunks from queue"""
        logger.info(f"Client {self.client_id}: Inference worker started")

        try:
            while self.running:
                try:
                    # Get audio chunk from queue with timeout
                    audio_data, event_id = await asyncio.wait_for(
                        self.inference_queue.get(), timeout=3.0
                    )

                    # Process the chunk
                    await self.process_audio_chunk_with_triton(audio_data, event_id)

                except asyncio.TimeoutError:
                    # No audio for 3 seconds, continue waiting
                    if self.chunks_received == 0:
                        continue
                    else:
                        logger.debug(f"Client {self.client_id}: No audio for 3s")
                        continue

        except asyncio.CancelledError:
            logger.info(f"Client {self.client_id}: Inference worker cancelled")
        except Exception as e:
            logger.error(f"Client {self.client_id}: Inference worker error: {e}", exc_info=True)
        finally:
            logger.info(f"Client {self.client_id}: Inference worker stopped")

    async def send_session_created(self):
        """Send session created message to client"""
        message = {
            "type": "session.created",
            "event_id": str(uuid.uuid4()),
            "session": {
                "id": self.client_id,
                "model": "nemotron-voicechat",
                "modalities": ["audio"],
                "input_audio_format": INPUT_AUDIO_FORMAT,
                "output_audio_format": OUTPUT_AUDIO_FORMAT,
                "input_audio_sample_rate": INPUT_OPUS_SAMPLE_RATE,  # Client should send at 24kHz
                "output_audio_sample_rate": OUTPUT_SAMPLE_RATE,
                "output_audio_channels": CHANNELS,
                "input_audio_channels": CHANNELS,
            },
        }
        try:
            await asyncio.wait_for(self.websocket.send_text(json.dumps(message)), timeout=5.0)
        except asyncio.TimeoutError:
            logger.error(f"Client {self.client_id}: Timeout sending session.created")
            raise
        logger.info(
            f"Client {self.client_id}: Session created - "
            f"sequence_id={self.sequence_id}, input: {INPUT_AUDIO_FORMAT}@{INPUT_OPUS_SAMPLE_RATE}Hz, output: {OUTPUT_AUDIO_FORMAT}@{OUTPUT_SAMPLE_RATE}Hz"
        )

    async def process_audio_chunk_with_triton(self, audio_data: str, event_id: str = None):
        """
        Process audio chunk through Triton inference

        Args:
            audio_data: Base64-encoded Opus audio data
            event_id: Optional event ID from the client
        """
        try:
            # Decode base64 to get Opus bytes
            opus_bytes = base64.b64decode(audio_data)

            # Validate Opus data
            if len(opus_bytes) == 0:
                logger.warning(f"Client {self.client_id}: Received empty Opus data")
                return

            # Log first chunk info for debugging
            if self.chunks_received == 1:
                logger.info(
                    f"Client {self.client_id}: First chunk - {len(opus_bytes)} bytes, "
                    f"first bytes: {opus_bytes[: min(8, len(opus_bytes))].hex()}"
                )

            # Decode Opus to PCM (24kHz, float32)
            try:
                self.opus_reader.append_bytes(opus_bytes)
                pcm_float32_24k = self.opus_reader.read_pcm()
            except ValueError as e:
                if "closed channel" in str(e):
                    # Recreate the opus reader if channel is closed
                    logger.warning(
                        f"Client {self.client_id}: Opus reader channel closed (chunk {self.chunks_received}, "
                        f"{len(opus_bytes)} bytes). This likely means the client is not sending valid Opus data."
                    )
                    self.opus_reader = OpusStreamReader(INPUT_OPUS_SAMPLE_RATE)
                    # Try again with fresh reader
                    try:
                        self.opus_reader.append_bytes(opus_bytes)
                        pcm_float32_24k = self.opus_reader.read_pcm()
                    except Exception as retry_error:
                        logger.error(
                            f"Client {self.client_id}: Failed to decode even after recreating reader. "
                            f"Client may be sending PCM instead of Opus. Error: {retry_error}"
                        )
                        return
                else:
                    raise

            # Check if we got any decoded audio
            if pcm_float32_24k.shape[-1] == 0:
                logger.debug(f"Client {self.client_id}: No PCM data decoded yet, buffering")
                return

            # For Triton processing: resample from 24kHz to 16kHz
            audio_float32_16k = signal.resample_poly(
                pcm_float32_24k, INPUT_SAMPLE_RATE, INPUT_OPUS_SAMPLE_RATE
            )

            # Add to Triton input buffer
            self.triton_input_buffer = np.concatenate([self.triton_input_buffer, audio_float32_16k])

            # Check if we have enough chunks for inference
            required_samples = self.triton_chunk_size * NUM_CHUNKS_PER_INFERENCE
            if len(self.triton_input_buffer) < required_samples:
                if self.chunks_received == 1:
                    logger.info(
                        f"Client {self.client_id}: Buffering for Triton - need {NUM_CHUNKS_PER_INFERENCE} chunks "
                        f"({required_samples} samples), have {len(self.triton_input_buffer)}"
                    )
                return  # Wait for more chunks

            # Extract buffered audio for inference
            audio_float32_buffered = self.triton_input_buffer[:required_samples]
            self.triton_input_buffer = self.triton_input_buffer[required_samples:]  # Keep remainder

            # Convert to int16 for Triton input
            audio_int16 = (audio_float32_buffered * 32768.0).astype(np.int16)

            # Convert int16 to float32 (normalize to -1.0 to 1.0)
            audio_float32 = audio_int16.astype(np.float32) / 32768.0

            # Ensure 2D shape (batch_size, samples)
            if len(audio_float32.shape) == 1:
                audio_float32 = np.expand_dims(audio_float32, axis=0)

            num_samples = audio_float32.shape[1]
            duration_ms = (num_samples / INPUT_SAMPLE_RATE) * 1000

            if self.triton_inferences == 0:  # Before first inference
                logger.info(
                    f"Client {self.client_id}: Sending to Triton - "
                    f"{num_samples} samples ({NUM_CHUNKS_PER_INFERENCE} chunks), {duration_ms:.1f}ms @ {INPUT_SAMPLE_RATE}Hz"
                )

            # Ensure Triton client is initialized
            if self.triton_client is None:
                raise Exception("Triton client not initialized for session")

            # Prepare Triton inputs
            inputs = [
                httpclient.InferInput(
                    "audio_signal", audio_float32.shape, np_to_triton_dtype(audio_float32.dtype)
                )
            ]
            inputs[0].set_data_from_numpy(audio_float32)

            # Prepare Triton outputs
            outputs = [
                httpclient.InferRequestedOutput("output_text"),
                httpclient.InferRequestedOutput("output_asr_text"),
                httpclient.InferRequestedOutput("output_audio"),
            ]

            # Call Triton inference
            request_id = str(uuid.uuid4())
            is_last_chunk = False  # Set to True when client disconnects

            # Track inference time
            infer_start = time.time()

            response = await asyncio.wait_for(
                self.triton_client.infer(
                    model_name=TRITON_MODEL_NAME,
                    inputs=inputs,
                    outputs=outputs,
                    request_id=request_id,
                    sequence_id=self.sequence_id,
                    sequence_start=False,  # Sequence already started during warmup
                    sequence_end=is_last_chunk,
                ),
                timeout=30.0,  # Reduced to 30 seconds to prevent WebSocket timeout
            )

            infer_time_ms = (time.time() - infer_start) * 1000
            self.triton_inferences += 1

            # Log inference timing
            # Note: Model takes 1 chunk at a time but produces output only after seeing 2 chunks
            if self.triton_inferences == 1:
                logger.info(
                    f"Client {self.client_id}: Inference #1 completed in {infer_time_ms:.1f}ms "
                    f"(audio: {duration_ms:.1f}ms, note: output available after chunk 2)"
                )
            elif self.triton_inferences <= 3:
                # First few inferences - just log as info (model stabilizing)
                logger.info(
                    f"Client {self.client_id}: Inference #{self.triton_inferences} completed in {infer_time_ms:.1f}ms "
                    f"(audio: {duration_ms:.1f}ms)"
                )
            elif infer_time_ms > duration_ms * 2:  # Slower than 2x real-time
                logger.warning(
                    f"Client {self.client_id}: Slow inference #{self.triton_inferences}: {infer_time_ms:.1f}ms "
                    f"(audio: {duration_ms:.1f}ms, {infer_time_ms / duration_ms:.1f}x real-time, queue: {self.inference_queue.qsize()})"
                )
            elif self.triton_inferences % 50 == 0:  # Periodic status
                logger.info(
                    f"Client {self.client_id}: Inference #{self.triton_inferences}: {infer_time_ms:.1f}ms "
                    f"(audio: {duration_ms:.1f}ms, {infer_time_ms / duration_ms:.1f}x real-time)"
                )

            # Extract outputs
            output_text = response.as_numpy("output_text")
            output_asr_text = response.as_numpy("output_asr_text")
            output_audio = response.as_numpy("output_audio")

            # Keep audio as float32 for Opus encoding (normalized to [-1.0, 1.0])
            output_audio_float32 = output_audio.astype(np.float32)

            # Resample from model output rate (22050Hz) to Opus output rate (24000Hz)
            if output_audio_float32.size > 0:
                # Flatten to 1D if needed
                if output_audio_float32.ndim > 1:
                    output_audio_float32 = output_audio_float32.flatten()
                # Resample 22050 -> 24000
                output_audio_float32 = signal.resample_poly(
                    output_audio_float32, OUTPUT_SAMPLE_RATE, MODEL_OUTPUT_SAMPLE_RATE
                )

            # Decode text outputs
            text_response = "".join([t.decode("utf-8") for t in output_text])
            asr_text_response = "".join([t.decode("utf-8") for t in output_asr_text])

            if text_response:
                logger.info(f"Client {self.client_id}: Text response: {text_response}")
            if asr_text_response:
                logger.info(f"Client {self.client_id}: ASR text: {asr_text_response}")

            # Send audio response
            if output_audio_float32.size > 0:
                try:
                    # Encode with Opus for transmission using stream writer
                    # Clip audio to valid range [-1.0, 1.0] to prevent distortion
                    output_audio_float32 = np.clip(output_audio_float32, -1.0, 1.0)

                    # Encode with proper frame buffering (send_loop will handle sending)
                    self.encode_to_opus(output_audio_float32)
                except Exception as encode_error:
                    logger.warning(
                        f"Client {self.client_id}: Failed to encode audio: {encode_error}"
                    )
                    raise  # Re-raise to stop processing

            # Send text response if available
            if text_response:
                try:
                    # Clean the agent text (remove markers)
                    clean_text = (
                        text_response.replace("^", "").replace("<s>", "").replace("</s>", "")
                    )

                    # Send the text delta (cleaned)
                    if clean_text:  # Only send if there's text after cleaning
                        text_msg = {
                            "type": "response.output_text.delta",
                            "event_id": str(uuid.uuid4()),
                            "delta": clean_text,
                        }
                        await self.websocket.send_text(json.dumps(text_msg))

                    # Accumulate agent transcript (original with markers for detection)
                    self.accumulated_agent_transcript.append(text_response)

                    # Check if transcript contains end-of-speech marker
                    if "</s>" in text_response:
                        # Send accumulated transcript (strip markers)
                        full_transcript = "".join(self.accumulated_agent_transcript)
                        # Remove markers: ^, <s>, </s>
                        clean_transcript = (
                            full_transcript.replace("^", "").replace("<s>", "").replace("</s>", "")
                        )

                        text_done_msg = {
                            "type": "response.output_text.done",
                            "event_id": str(uuid.uuid4()),
                            "text": clean_transcript,
                        }
                        await self.websocket.send_text(json.dumps(text_done_msg))
                        logger.info(
                            f"Client {self.client_id}: Agent transcript completed: {clean_transcript}"
                        )

                        # Reset accumulation for next utterance
                        self.accumulated_agent_transcript = []

                except Exception as send_error:
                    logger.warning(f"Client {self.client_id}: Failed to send text: {send_error}")
                    raise

            # Send ASR text if available
            if asr_text_response:
                try:
                    # Clean the ASR text (remove markers)
                    clean_asr_text = (
                        asr_text_response.replace("^", "").replace("<s>", "").replace("</s>", "")
                    )

                    # Send the ASR delta (cleaned)
                    if clean_asr_text:  # Only send if there's text after cleaning
                        asr_msg = {
                            "type": "conversation.item.input_audio_transcription.delta",
                            "event_id": str(uuid.uuid4()),
                            "delta": clean_asr_text,
                        }
                        await self.websocket.send_text(json.dumps(asr_msg))

                    # Check if transcript contains end-of-speech marker
                    if "</s>" in asr_text_response:
                        # Send accumulated transcript (strip markers)
                        full_transcript = "".join(self.accumulated_user_transcript)
                        # Remove markers: ^, <s>, </s>
                        clean_transcript = (
                            full_transcript.replace("^", "").replace("<s>", "").replace("</s>", "")
                        )
                        transcript_msg = {
                            "type": "conversation.item.input_audio_transcription.completed",
                            "event_id": str(uuid.uuid4()),
                            "transcript": clean_transcript,
                        }
                        await self.websocket.send_text(json.dumps(transcript_msg))
                        logger.info(
                            f"Client {self.client_id}: User transcript completed: {clean_transcript}"
                        )

                        # Reset accumulation for next utterance
                        self.accumulated_user_transcript = []

                except Exception as send_error:
                    logger.warning(
                        f"Client {self.client_id}: Failed to send ASR text: {send_error}"
                    )
                    raise

            if self.chunks_received % 50 == 0:
                logger.info(
                    f"Client {self.client_id}: Processed {self.chunks_received} chunks, "
                    f"sent {self.chunks_sent}"
                )

        except asyncio.TimeoutError:
            logger.error(f"Client {self.client_id}: Triton inference timeout after 30s")
            # Try to send error message to client
            try:
                error_msg = {
                    "type": "error",
                    "event_id": str(uuid.uuid4()),
                    "error": {"message": "Inference timeout", "code": "inference_timeout"},
                }
                await self.websocket.send_text(json.dumps(error_msg))
            except Exception:
                logger.debug(
                    f"Client {self.client_id}: Could not send error message (client may have disconnected)"
                )
        except (WebSocketDisconnect, ConnectionResetError, RuntimeError) as e:
            # Client disconnected - this is normal, just log and stop processing
            logger.info(f"Client {self.client_id}: Client disconnected during processing: {e}")
            raise  # Re-raise to stop the session
        except Exception as e:
            logger.error(f"Client {self.client_id}: Error processing audio: {e}", exc_info=True)
            # Try to send error message to client
            try:
                error_msg = {
                    "type": "error",
                    "event_id": str(uuid.uuid4()),
                    "error": {"message": str(e), "code": "inference_error"},
                }
                await self.websocket.send_text(json.dumps(error_msg))
            except Exception:
                logger.debug(
                    f"Client {self.client_id}: Could not send error message (client may have disconnected)"
                )

    async def finalize_sequence(self):
        """Send final empty chunk to close Triton sequence"""
        try:
            if self.triton_client is None:
                logger.warning(f"Client {self.client_id}: No Triton client to finalize")
                return

            logger.info(f"Client {self.client_id}: Finalizing inference sequence")

            # Send empty chunk with sequence_end=True
            empty_audio = np.zeros(
                (1, int(TRITON_CHUNK_DURATION_SECS * INPUT_SAMPLE_RATE)), dtype=np.float32
            )

            inputs = [
                httpclient.InferInput(
                    "audio_signal", empty_audio.shape, np_to_triton_dtype(empty_audio.dtype)
                )
            ]
            inputs[0].set_data_from_numpy(empty_audio)

            outputs = [
                httpclient.InferRequestedOutput("output_text"),
                httpclient.InferRequestedOutput("output_asr_text"),
                httpclient.InferRequestedOutput("output_audio"),
            ]

            await self.triton_client.infer(
                model_name=TRITON_MODEL_NAME,
                inputs=inputs,
                outputs=outputs,
                request_id=str(uuid.uuid4()),
                sequence_id=self.sequence_id,
                sequence_start=False,
                sequence_end=True,
            )

            logger.info(f"Client {self.client_id}: Sequence finalized")

        except Exception as e:
            logger.error(f"Client {self.client_id}: Error finalizing sequence: {e}")

    async def handle_session_update(self, session_config: dict):
        """Handle session configuration update"""
        logger.info(f"Client {self.client_id}: Session update: {session_config}")
        message = {
            "type": "session.updated",
            "event_id": str(uuid.uuid4()),
            "session": session_config,
        }
        try:
            await asyncio.wait_for(self.websocket.send_text(json.dumps(message)), timeout=5.0)
        except asyncio.TimeoutError:
            logger.error(f"Client {self.client_id}: Timeout sending session.updated")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup and shutdown events"""
    # Get port from environment variable (set by main() before uvicorn.run)
    port = int(os.getenv("SERVER_PORT", "9000"))
    ssl_enabled = os.getenv("SSL_ENABLED", "false") == "true"
    protocol = "wss" if ssl_enabled else "ws"

    logger.info("=" * 60)
    logger.info("Nemotron VoiceChat Server - Audio WebSocket with Triton Inference")
    logger.info("=" * 60)
    logger.info(f"Server: {protocol}://0.0.0.0:{port}/v1/realtime")

    logger.info(f"Triton: {TRITON_URL}, Model: {TRITON_MODEL_NAME}")

    logger.info(
        f"Format: Input {INPUT_AUDIO_FORMAT}@{INPUT_OPUS_SAMPLE_RATE}Hz → Output {OUTPUT_AUDIO_FORMAT}@{OUTPUT_SAMPLE_RATE}Hz (Model: {INPUT_SAMPLE_RATE}Hz)"
    )
    logger.info(f"Health: http://0.0.0.0:{port}/v1/realtime/health")
    logger.info("Press Ctrl+C to stop")
    logger.info("=" * 60)

    # Only one active WebSocket session is supported at a time,
    # as the model's backend in triton doesn't allow multiple concurrent
    # users.
    app.state.session_lock = asyncio.Lock()

    triton_sequence_manager.warm_up()

    yield

    # Cleanup
    logger.info("\nShutting down Nemotron VoiceChat Server")
    await triton_manager.close()


# Create FastAPI app
app = FastAPI(title="Nemotron VoiceChat Server", version="0.2.0", lifespan=lifespan)


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "nemotron-voicechat",
        "version": "0.2.0",
        "websocket": "/v1/realtime",
        "health": "/v1/realtime/health",
        "triton_url": TRITON_URL,
        "model_name": TRITON_MODEL_NAME,
    }


@app.get("/v1/realtime/health")
async def health_check():
    """Health check endpoint"""
    triton_status = "unknown"
    error_message = None
    try:
        client = await triton_manager.get_client()
        is_ready = await client.is_server_ready()
        triton_status = "ready" if is_ready else "not_ready"

        if not is_ready:
            error_message = "Triton server is not ready"
    except Exception as e:
        triton_status = "error"
        error_message = str(e)

    # Determine overall status
    status = "ok" if triton_status == "ready" else "error"

    response = {
        "status": status,
        "service": "audio-websocket-server",
        "mode": "triton",
        "triton_status": triton_status,
    }

    if error_message:
        response["error"] = error_message

    return response


async def handle_websocket(websocket: WebSocket):
    """Handle WebSocket connection for real-time audio communication"""
    client_id = str(uuid.uuid4())[:8]
    await websocket.accept()
    logger.info(f"Client {client_id} connected from {websocket.client}")

    async with app.state.session_lock:
        session = AudioSession(client_id, websocket)

        try:
            # Wait for a pre-warmed sequence (blocks until one is ready)
            logger.info(f"Client {client_id}: Waiting for pre-warmed sequence...")
            prewarm_seq_id = await triton_sequence_manager.get_seq_id()
            logger.info(f"Client {client_id}: Using pre-warmed sequence_id={prewarm_seq_id}")
            session.sequence_id = prewarm_seq_id
            session.triton_client = await triton_manager.get_client()

            # Start background inference worker
            await session.start_inference_worker()

            await session.send_session_created()

            while True:
                try:
                    raw_message = await websocket.receive_text()

                    try:
                        data = json.loads(raw_message)
                        message_type = data.get("type")

                        if message_type == "input_audio_buffer.append":
                            audio_data = data.get("audio")
                            event_id = data.get("event_id")

                            if audio_data:
                                # Queue audio for async processing (non-blocking)
                                await session.queue_audio_chunk(audio_data, event_id)
                            else:
                                logger.warning(f"Client {client_id}: Audio message without data")

                        elif message_type == "session.update":
                            session_config = data.get("session", {})
                            await session.handle_session_update(session_config)

                        else:
                            logger.debug(f"Client {client_id}: Message type: {message_type}")

                    except json.JSONDecodeError as e:
                        logger.error(f"Client {client_id}: Invalid JSON: {e}")
                    except Exception as e:
                        logger.error(
                            f"Client {client_id}: Error processing message: {e}", exc_info=True
                        )

                except WebSocketDisconnect:
                    logger.info(f"Client {client_id}: WebSocket disconnected")
                    break

        except Exception as e:
            logger.error(f"Client {client_id}: Unexpected error: {e}", exc_info=True)

        finally:
            await session.stop_inference_worker()

            if session.sequence_id is not None:
                try:
                    await session.finalize_sequence()
                except Exception as e:
                    logger.warning(f"Client {client_id}: Error finalizing sequence: {e}")

            logger.info(
                f"Client {client_id}: Session ended - "
                f"Received: {session.chunks_received}, Sent: {session.chunks_sent}, "
                f"Dropped: {session.chunks_dropped}"
            )

            # Start pre-warming the next sequence for the next client
            triton_sequence_manager.warm_up()


# Register WebSocket routes (support both paths for compatibility)
@app.websocket("/v1/realtime")
async def websocket_endpoint_v1(websocket: WebSocket):
    """WebSocket endpoint at /v1/realtime (original path)"""
    await handle_websocket(websocket)


@app.websocket("/realtime")
async def websocket_endpoint_root(websocket: WebSocket):
    """WebSocket endpoint at /realtime (for  OpenAI SDK compatibility)"""
    await handle_websocket(websocket)


if __name__ == "__main__":
    import argparse

    import uvicorn

    # Parse command-line arguments
    parser = argparse.ArgumentParser(
        description="Nemotron VoiceChat Server - Audio WebSocket with Triton Inference"
    )
    parser.add_argument(
        "--port", type=int, default=9000, help="Port to run the server on (default: 9000)"
    )
    parser.add_argument("--ssl-certfile", type=str, help="SSL certificate file (for HTTPS/WSS)")
    parser.add_argument("--ssl-keyfile", type=str, help="SSL private key file (for HTTPS/WSS)")
    args = parser.parse_args()

    # Set port and SSL status in environment so lifespan can access it
    os.environ["SERVER_PORT"] = str(args.port)
    os.environ["SSL_ENABLED"] = "true" if args.ssl_certfile and args.ssl_keyfile else "false"

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=args.port,
        log_level="info",
        ssl_certfile=args.ssl_certfile,
        ssl_keyfile=args.ssl_keyfile,
        ws_max_size=10 * 1024 * 1024,
        ws_ping_interval=30.0,  # Send ping every 30 seconds
        ws_ping_timeout=120.0,  # Wait up to 120 seconds for pong
        timeout_keep_alive=300,  # Keep connection alive for 5 minutes
    )
