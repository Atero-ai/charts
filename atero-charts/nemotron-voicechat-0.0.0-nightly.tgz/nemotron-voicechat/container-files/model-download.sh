#!/bin/bash
set -e

# Required environment variables:
#   MODEL_MOUNT_PATH    - base path for model storage (e.g. /mnt/nvme_raid/models)
#   MODEL_DIR_NAME      - model directory name (e.g. nemotron-voicechat_v26.01.20.1)
#   NGC_CLI_VERSION     - NGC CLI version to download (e.g. 4.13.0)
#   NGC_ORG             - NGC organization (e.g. nvidia)
#   NGC_CLI_API_KEY     - NGC API key (read natively by NGC CLI)
#   NGC_MODEL_PATH      - NGC model path (e.g. ea-riva/s2s/nemotron-voicechat:26.01.20.1)
#   CONFIG_PBTXT_SUBDIR - subdirectory containing config.pbtxt
#   INSTANCE_GROUP      - Triton instance group config line
#   MAX_SEQ_IDLE_US     - max sequence idle microseconds

MODEL_DIR="${MODEL_MOUNT_PATH}/${MODEL_DIR_NAME}"
READY_MARKER="${MODEL_DIR}/.model-ready"

if [ ! -f "$READY_MARKER" ]; then
    # Clean up any partial state from a previous interrupted run.
    # Safe to do under flock — no other init container is running concurrently.
    rm -rf "$MODEL_DIR"

    echo "Model not ready, downloading and patching..."

    wget --content-disposition "https://api.ngc.nvidia.com/v2/resources/nvidia/ngc-apps/ngc_cli/versions/${NGC_CLI_VERSION}/files/ngccli_linux.zip" -O /tmp/ngccli_linux.zip
    unzip -o /tmp/ngccli_linux.zip -d /tmp/
    chmod u+x /tmp/ngc-cli/ngc
    export PATH="$PATH:/tmp/ngc-cli"

    mkdir -p ~/.ngc
    printf '[CURRENT]\napikey = %s\nformat_type = ascii\norg = %s\n' "$NGC_CLI_API_KEY" "$NGC_ORG" > ~/.ngc/config

    cd "$MODEL_MOUNT_PATH"
    ngc registry model download-version "$NGC_MODEL_PATH"
    echo "Download complete, patching model config."

    sed -i "/instance_group/c\\${INSTANCE_GROUP}" "${MODEL_DIR}/${CONFIG_PBTXT_SUBDIR}/config.pbtxt"
    sed -i "s/max_sequence_idle_microseconds:.*/max_sequence_idle_microseconds: ${MAX_SEQ_IDLE_US}/" "${MODEL_DIR}/${CONFIG_PBTXT_SUBDIR}/config.pbtxt"

    touch "$READY_MARKER"
    echo "Patch complete, model-download.sh script done."
else
    echo "Model already ready at $MODEL_DIR, skipping download and patch."
fi
