# Helm Chart Configuration - Developer Guide

## Critical Rule: Schema, Values, and Templates Synchronization

**⚠️ IMPORTANT: When making changes to configuration, ALL THREE locations must be updated in sync:**

1. **`config-schema.json`** - JSON Schema validation for configuration
2. **`values.yaml`** - Default values for Helm chart
3. **`templates/*.yaml`** - Helm template files (especially `job.yaml`)

### Why All Three?

- **`config-schema.json`**: Defines the contract - what fields exist, their types, constraints, and validation rules
- **`values.yaml`**: Provides default values that conform to the schema
- **`templates/*.yaml`**: Uses the values to render Kubernetes manifests

These files must stay in sync to ensure:
- Configuration validation works correctly
- Default values are valid according to the schema
- Templates reference existing value paths
- Documentation is consistent across all files
- Users get clear error messages when values are invalid

### Change Workflow

When adding, removing, or modifying a configuration field:

1. **Update `config-schema.json`**:
   - Add/remove/modify the property definition
   - Update type, enum, default, description
   - Add/remove from `required` arrays if needed
   - Update validation rules (minimum, maximum, pattern, etc.)

2. **Update `values.yaml`**:
   - Add/remove/modify the corresponding value
   - Ensure default matches schema's default
   - Update comments to match schema's description
   - Ensure value satisfies schema constraints

3. **Update `templates/*.yaml`** (especially `job.yaml`):
   - Find all references to the old value path (use grep/search)
   - Update `.Values.path.to.field` references
   - Update conditionals: `{{- if .Values.path.to.field }}`
   - Update value access: `{{ .Values.path.to.field }}`
   - Check for both quoted and unquoted references

4. **Test all changes**:
   ```bash
   # Validate schema syntax
   jq . config-schema.json > /dev/null

   # Validate values against schema
   # (TODO: Add automated validation script)

   # Test Helm rendering
   helm template test . -f values.yaml

   # Search for old field references
   grep -r "oldFieldPath" templates/
   ```

### Examples

**Example 1: Adding a new field**

```diff
# config-schema.json
"properties": {
+  "newField": {
+    "type": "string",
+    "default": "default-value",
+    "description": "Description of new field"
+  }
}

# values.yaml
+# Description of new field
+newField: "default-value"

# templates/job.yaml (if used in templates)
+          {{- if .Values.newField }}
+          - --new-field
+          - {{ .Values.newField }}
+          {{- end }}
```

**Example 2: Removing a field**

```diff
# config-schema.json
"properties": {
-  "oldField": {
-    "type": "string",
-    "default": "old-value"
-  }
}

# values.yaml
-# Old field description
-oldField: "old-value"

# templates/job.yaml (remove template references)
-          {{- if .Values.oldField }}
-          - --old-field
-          - {{ .Values.oldField }}
-          {{- end }}
```

**Example 3: Changing a default value**

```diff
# config-schema.json
"properties": {
  "someField": {
    "type": "integer",
-   "default": 100
+   "default": 200
  }
}

# values.yaml
-someField: 100
+someField: 200

# templates/job.yaml - no change needed (references stay the same)
```

**Example 4: Restructuring nested fields**

```diff
# config-schema.json
"properties": {
-  "oldFieldName": {
-    "type": "string"
-  }
+  "parent": {
+    "type": "object",
+    "properties": {
+      "newFieldName": {
+        "type": "string"
+      }
+    }
+  }
}

# values.yaml
-oldFieldName: "value"
+parent:
+  newFieldName: "value"

# templates/job.yaml - CRITICAL: Update all references
-          - {{ .Values.oldFieldName }}
+          - {{ .Values.parent.newFieldName }}
```

### Common Mistakes to Avoid

❌ **Don't**: Update only `values.yaml` - schema will be outdated
❌ **Don't**: Update only `config-schema.json` - defaults will be inconsistent
❌ **Don't**: Forget to update templates when changing value paths
❌ **Don't**: Have mismatched defaults between schema and values
❌ **Don't**: Forget to update `required` arrays when adding mandatory fields
❌ **Don't**: Leave old field references in templates after renaming

✅ **Do**: Update all three locations in the same commit
✅ **Do**: Keep descriptions and comments synchronized
✅ **Do**: Search templates for old field references after renaming
✅ **Do**: Validate changes before committing
✅ **Do**: Test Helm rendering after changes
✅ **Do**: Use grep to find all template references: `grep -r "fieldName" templates/`

### Schema Structure Notes

The schema uses a **category-based structure**:
- Top-level fields: Infrastructure config (database, prometheus, image, etc.)
- Category fields: Benchmark-specific config (performance, accuracy, quality)
- Category sub-fields: Benchmark implementation variants (serving, simple)

When adding configuration:
- **Infrastructure-level**: Add at top level if it applies to all benchmarks
- **Category-level**: Add under `performance`, `accuracy`, or `quality` if it's category-specific
- **Implementation-level**: Add under `serving` or `simple` if it's specific to one benchmark type

### Validation

The schema includes validation rules:
- `type`: Data type (string, integer, number, boolean, array, object)
- `enum`: Allowed values (finite set of options)
- `minimum`/`maximum`: Numeric bounds
- `pattern`: Regex pattern for strings
- `required`: Mandatory fields
- `default`: Default value (must match type and constraints)

Always ensure:
- Defaults satisfy validation rules
- Enum values include the default
- Required fields exist in values.yaml
- Types match between schema and values

## File Locations

- **Schema**: `charts/wrenchmark/config-schema.json`
- **Values**: `charts/wrenchmark/values.yaml`
- **This guide**: `charts/wrenchmark/CLAUDE.md`
